"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
/* tslint:disable */
require("./IntraEmployeesWebPart.module.css");
var styles = {
    intraEmployees: 'intraEmployees_31e185d5',
    container: 'container_31e185d5',
    row: 'row_31e185d5',
    column: 'column_31e185d5',
    'ms-Grid': 'ms-Grid_31e185d5',
    title: 'title_31e185d5',
    subTitle: 'subTitle_31e185d5',
    description: 'description_31e185d5',
    button: 'button_31e185d5',
    label: 'label_31e185d5',
};
exports.default = styles;
/* tslint:enable */ 
//# sourceMappingURL=IntraEmployeesWebPart.module.scss.js.map