declare interface IIntraEmployeesWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'IntraEmployeesWebPartStrings' {
  const strings: IIntraEmployeesWebPartStrings;
  export = strings;
}
