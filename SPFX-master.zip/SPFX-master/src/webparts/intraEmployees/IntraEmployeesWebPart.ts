import { Version } from '@microsoft/sp-core-library';
import {
  BaseClientSideWebPart,
  IPropertyPaneConfiguration,
  PropertyPaneTextField
} from '@microsoft/sp-webpart-base';
import { Web } from "sp-pnp-js/lib/sharepoint/webs";
import * as strings from 'IntraEmployeesWebPartStrings';

export interface IIntraEmployeesWebPartProps {
  description: string;
}
export interface ISPLists {
  value: ISPList[];
}
export interface ISPList {
  EmployeeImage: string;
  Name: string;
  DOBDD: any;
  DOBMM: string;
}

export default class IntraEmployeesWebPart extends BaseClientSideWebPart<IIntraEmployeesWebPartProps> {

  public render(): void {
    this.domElement.innerHTML = `
      <div class="col-md-12 rightleftPaddingRemove">
            <div class="block">
              <div class="quick_link_header block_header">
                <h1><i class="fa fa-birthday-cake" aria-hidden="true"></i> Stridelians Birthday's</h1>
              </div>
              <div id="TodayBDay" class="birthday_main">
              </div>
            </div>
      </div>`;
    this._renderListAsync();
  }

  protected get dataVersion(): Version {
    return Version.parse('1.0');
  }
  private _getListByEmployeeBD() {
    var Today = new Date();
    var dd = Today.getDate();
    var mm = Today.getMonth() + 1;
    var yyyy = Today.getFullYear();
    var dateonly = "";
    var month = "";
    if (dd < 10) {
      dateonly = "0" + dd;
    }
    else {
      dateonly = dd + "";
    }
    if (mm < 10) {
      month = "0" + mm;
    }
    else {
      month = mm + "";
    }
    let web = new Web(this.context.pageContext.web.absoluteUrl);
    return web.lists.getByTitle('Intra-Employees').items.filter("DOBDD ge '" + dateonly + "' and DOBMM eq '" + month + "'").orderBy('DOBDD', true).get().then((items: any) => {
      return items;
    });
  }
  private _renderListAsync(): any {
    this._getListByEmployeeBD().then((EventRes) => {
      this.renderIntraEmployeeBDlist(EventRes);
    });
  }

  private renderIntraEmployeeBDlist(IntraEmployeeBDlistitem: ISPList[]): void {
    var bdaygif = `${this.context.pageContext.web.absoluteUrl}/CDN/img/cake.gif`
    /*var myArray = [
      "Happy birthday! I hope all your birthday wishes and dreams come true.",
    ];
    var randomItem = myArray[Math.floor(Math.random() * myArray.length)]; */
    const monthNames = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
    var Today = new Date();
    var monthname = (monthNames[Today.getMonth()])
    let EventAnnhtml: string = ``;
    EventAnnhtml += ``;
    IntraEmployeeBDlistitem.forEach((IntraEmployeeBDlistitem: ISPList) => {
      var dateonly1 = "";
      var month1 = "";
      var dd1 = Today.getDate();
      var mm1 = Today.getMonth() + 1;
      if (dd1 < 10) {
      dateonly1 = "0" + dd1;
    }
    else {
      dateonly1 = dd1 + "";
    }
    if (mm1 < 10) {
      month1 = "0" + mm1;
    }
    else {
      month1 = mm + "";
    }
      var dd = IntraEmployeeBDlistitem.DOBDD;
      var mm = IntraEmployeeBDlistitem.DOBMM;
      if (dd == dateonly1 && (month1 == mm)) {
        EventAnnhtml += `
           <div class="hr">
            <div class="birthday_user col-md-4 float-left" aria-hidden="true">
              <img src="${IntraEmployeeBDlistitem.EmployeeImage['Url']}">
            </div>
          <div class="birthday col-md-8 float-left">
            <h3>${IntraEmployeeBDlistitem.Name}</h3>
            <p><img src="${bdaygif}" alt="Cake" id="BDayCake" style=" border-radius: 0px; width: 20px; margin-top: -10px; margin-right: 5px;"><b>Happy birthday</b></p>
          </div>
          <br clear="all">
          </div>`
      }
      else  {
        EventAnnhtml += `
           <div class="hr">
            <div class="birthday_user col-md-4 float-left" aria-hidden="true">
              <img src="${IntraEmployeeBDlistitem.EmployeeImage['Url']}">
            </div>
          <div class="birthday col-md-8 float-left">
            <h3>${IntraEmployeeBDlistitem.Name}</h3>        
            <p>${IntraEmployeeBDlistitem.DOBDD} ${monthname}</p>
          </div>
          <br clear="all">
          </div>`}
    });
    const EventContainer: Element = this.domElement.querySelector('#TodayBDay');
    if (EventAnnhtml.length > 0)
      EventContainer.innerHTML = EventAnnhtml;
    else {
      EventContainer.innerHTML = `
        <div class="hr">
            <div class="birthday col-md-12 float-left">
              <h3>No birthday's today. Hoping tomorrow </h3>
            </div>
            <br clear="all">  
          </div>`;
    }
  }
  protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration {
    return {
      pages: [
        {
          header: {
            description: strings.PropertyPaneDescription
          },
          groups: [
            {
              groupName: strings.BasicGroupName,
              groupFields: [
                PropertyPaneTextField('description', {
                  label: strings.DescriptionFieldLabel
                })
              ]
            }
          ]
        }
      ]
    };
  }
}
