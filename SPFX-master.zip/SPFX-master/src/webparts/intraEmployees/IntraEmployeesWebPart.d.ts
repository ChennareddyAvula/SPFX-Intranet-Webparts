import { Version } from '@microsoft/sp-core-library';
import { BaseClientSideWebPart, IPropertyPaneConfiguration } from '@microsoft/sp-webpart-base';
export interface IIntraEmployeesWebPartProps {
    description: string;
}
export interface ISPLists {
    value: ISPList[];
}
export interface ISPList {
    EmployeeImage: string;
    Name: string;
    DOBDD: any;
    DOBMM: string;
}
export default class IntraEmployeesWebPart extends BaseClientSideWebPart<IIntraEmployeesWebPartProps> {
    render(): void;
    protected readonly dataVersion: Version;
    private _getListByEmployeeBD;
    private _renderListAsync;
    private renderIntraEmployeeBDlist;
    protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration;
}
