"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
var sp_core_library_1 = require("@microsoft/sp-core-library");
var sp_webpart_base_1 = require("@microsoft/sp-webpart-base");
var webs_1 = require("sp-pnp-js/lib/sharepoint/webs");
var strings = require("IntraEmployeesWebPartStrings");
var IntraEmployeesWebPart = /** @class */ (function (_super) {
    __extends(IntraEmployeesWebPart, _super);
    function IntraEmployeesWebPart() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    IntraEmployeesWebPart.prototype.render = function () {
        this.domElement.innerHTML = "\n      <div class=\"col-md-12 rightleftPaddingRemove\">\n            <div class=\"block\">\n              <div class=\"quick_link_header block_header\">\n                <h1><i class=\"fa fa-birthday-cake\" aria-hidden=\"true\"></i> Stridelians Birthday's</h1>\n              </div>\n              <div id=\"TodayBDay\" class=\"birthday_main\">\n              </div>\n            </div>\n      </div>";
        this._renderListAsync();
    };
    Object.defineProperty(IntraEmployeesWebPart.prototype, "dataVersion", {
        get: function () {
            return sp_core_library_1.Version.parse('1.0');
        },
        enumerable: true,
        configurable: true
    });
    IntraEmployeesWebPart.prototype._getListByEmployeeBD = function () {
        var Today = new Date();
        var dd = Today.getDate();
        var mm = Today.getMonth() + 1;
        var yyyy = Today.getFullYear();
        var dateonly = "";
        var month = "";
        if (dd < 10) {
            dateonly = "0" + dd;
        }
        else {
            dateonly = dd + "";
        }
        if (mm < 10) {
            month = "0" + mm;
        }
        else {
            month = mm + "";
        }
        var web = new webs_1.Web(this.context.pageContext.web.absoluteUrl);
        return web.lists.getByTitle('Intra-Employees').items.filter("DOBDD ge '" + dateonly + "' and DOBMM eq '" + month + "'").orderBy('DOBDD', true).get().then(function (items) {
            return items;
        });
    };
    IntraEmployeesWebPart.prototype._renderListAsync = function () {
        var _this = this;
        this._getListByEmployeeBD().then(function (EventRes) {
            _this.renderIntraEmployeeBDlist(EventRes);
        });
    };
    IntraEmployeesWebPart.prototype.renderIntraEmployeeBDlist = function (IntraEmployeeBDlistitem) {
        var bdaygif = this.context.pageContext.web.absoluteUrl + "/CDN/img/cake.gif";
        /*var myArray = [
          "Happy birthday! I hope all your birthday wishes and dreams come true.",
        ];
        var randomItem = myArray[Math.floor(Math.random() * myArray.length)]; */
        var monthNames = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
        var Today = new Date();
        var monthname = (monthNames[Today.getMonth()]);
        var EventAnnhtml = "";
        EventAnnhtml += "";
        IntraEmployeeBDlistitem.forEach(function (IntraEmployeeBDlistitem) {
            var dateonly1 = "";
            var month1 = "";
            var dd1 = Today.getDate();
            var mm1 = Today.getMonth() + 1;
            if (dd1 < 10) {
                dateonly1 = "0" + dd1;
            }
            else {
                dateonly1 = dd1 + "";
            }
            if (mm1 < 10) {
                month1 = "0" + mm1;
            }
            else {
                month1 = mm + "";
            }
            var dd = IntraEmployeeBDlistitem.DOBDD;
            var mm = IntraEmployeeBDlistitem.DOBMM;
            if (dd == dateonly1 && (month1 == mm)) {
                EventAnnhtml += "\n           <div class=\"hr\">\n            <div class=\"birthday_user col-md-4 float-left\" aria-hidden=\"true\">\n              <img src=\"" + IntraEmployeeBDlistitem.EmployeeImage['Url'] + "\">\n            </div>\n          <div class=\"birthday col-md-8 float-left\">\n            <h3>" + IntraEmployeeBDlistitem.Name + "</h3>\n            <p><img src=\"" + bdaygif + "\" alt=\"Cake\" id=\"BDayCake\" style=\" border-radius: 0px; width: 20px; margin-top: -10px; margin-right: 5px;\"><b>Happy birthday</b></p>\n          </div>\n          <br clear=\"all\">\n          </div>";
            }
            else {
                EventAnnhtml += "\n           <div class=\"hr\">\n            <div class=\"birthday_user col-md-4 float-left\" aria-hidden=\"true\">\n              <img src=\"" + IntraEmployeeBDlistitem.EmployeeImage['Url'] + "\">\n            </div>\n          <div class=\"birthday col-md-8 float-left\">\n            <h3>" + IntraEmployeeBDlistitem.Name + "</h3>        \n            <p>" + IntraEmployeeBDlistitem.DOBDD + " " + monthname + "</p>\n          </div>\n          <br clear=\"all\">\n          </div>";
            }
        });
        var EventContainer = this.domElement.querySelector('#TodayBDay');
        if (EventAnnhtml.length > 0)
            EventContainer.innerHTML = EventAnnhtml;
        else {
            EventContainer.innerHTML = "\n        <div class=\"hr\">\n            <div class=\"birthday col-md-12 float-left\">\n              <h3>No birthday's today. Hoping tomorrow </h3>\n            </div>\n            <br clear=\"all\">  \n          </div>";
        }
    };
    IntraEmployeesWebPart.prototype.getPropertyPaneConfiguration = function () {
        return {
            pages: [
                {
                    header: {
                        description: strings.PropertyPaneDescription
                    },
                    groups: [
                        {
                            groupName: strings.BasicGroupName,
                            groupFields: [
                                sp_webpart_base_1.PropertyPaneTextField('description', {
                                    label: strings.DescriptionFieldLabel
                                })
                            ]
                        }
                    ]
                }
            ]
        };
    };
    return IntraEmployeesWebPart;
}(sp_webpart_base_1.BaseClientSideWebPart));
exports.default = IntraEmployeesWebPart;
//# sourceMappingURL=IntraEmployeesWebPart.js.map