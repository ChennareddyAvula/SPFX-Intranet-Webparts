declare interface IIntraCeoUpdatesWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'IntraCeoUpdatesWebPartStrings' {
  const strings: IIntraCeoUpdatesWebPartStrings;
  export = strings;
}
