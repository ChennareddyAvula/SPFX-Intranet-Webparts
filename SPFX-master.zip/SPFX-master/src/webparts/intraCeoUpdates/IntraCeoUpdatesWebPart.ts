import { Version } from '@microsoft/sp-core-library';
import {
  BaseClientSideWebPart,
  IPropertyPaneConfiguration,
  PropertyPaneTextField
} from '@microsoft/sp-webpart-base';
import { Web } from "sp-pnp-js/lib/sharepoint/webs";
import * as strings from 'IntraCeoUpdatesWebPartStrings';

export interface IIntraCeoUpdatesWebPartProps {
  description: string;
}
export interface ISPLists {
  value: ISPList[];
}
export interface ISPList {
  Image: string;
  Description: string;
  Title: string;
}
export default class IntraCeoUpdatesWebPart extends BaseClientSideWebPart<IIntraCeoUpdatesWebPartProps> {
  public render(): void {
    this.domElement.innerHTML = `
    <div class="col-md-12 rightleftPaddingRemove">
            <div class="block">
              <div class="quick_link_header block_header">
                <h1><i class="fa fa-users" aria-hidden="true"></i> Top Management Updates</h1>
              </div>
              <div class="ceo_update">
                <div class="card">
                  <div id="carouselExampleControls" class="carousel slide" data-ride="carousel" data-interval="100000">
                    <div class="w-100 carousel-inner" role="listbox">
                      <div class="carousel-item active">
                        <div class="">
                          <div id="CeoUpdates" class="row carousel_row">
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>`;
    this._renderListAsync();
  }

  protected get dataVersion(): Version {
    return Version.parse('1.0');
  }

  private _getListByCeoUpdates() {
     let web = new Web(this.context.pageContext.web.absoluteUrl);
     return web.lists.getByTitle('Intra-CEOUpdates').items.get().then((items: any) => {
     return items;
    });
  }
  private _renderListAsync(): any {
      this._getListByCeoUpdates().then((EventRes) => {
      this.renderCeoUpdates(EventRes);
    });
  }
  private renderCeoUpdates(CeoUpdatesItems: ISPList[]): void {
    let EventAnnhtml: string = ``;
    EventAnnhtml += ``;
    CeoUpdatesItems.forEach((CeoUpdatesItems: ISPList) => {
      EventAnnhtml += `<div class="col-sm-3"> <img src="${CeoUpdatesItems.Image['Url']}" alt="" class="img-fluid"/> </div>
                            <div class="col-sm-9">
                              <h3>${CeoUpdatesItems.Title}</h3>
                              <medium>${CeoUpdatesItems.Description}</medium> </div>
                          </div>`;
    });
    const EventContainer: Element = this.domElement.querySelector('#CeoUpdates');
    EventContainer.innerHTML = EventAnnhtml;
  }

  protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration {
    return {
      pages: [
        {
          header: {
            description: strings.PropertyPaneDescription
          },
          groups: [
            {
              groupName: strings.BasicGroupName,
              groupFields: [
                PropertyPaneTextField('description', {
                  label: strings.DescriptionFieldLabel
                })
              ]
            }
          ]
        }
      ]
    };
  }
}