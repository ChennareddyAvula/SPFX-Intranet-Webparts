"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
/* tslint:disable */
require("./IntraCeoUpdatesWebPart.module.css");
var styles = {
    intraCeoUpdates: 'intraCeoUpdates_c1687852',
    container: 'container_c1687852',
    row: 'row_c1687852',
    column: 'column_c1687852',
    'ms-Grid': 'ms-Grid_c1687852',
    title: 'title_c1687852',
    subTitle: 'subTitle_c1687852',
    description: 'description_c1687852',
    button: 'button_c1687852',
    label: 'label_c1687852',
};
exports.default = styles;
/* tslint:enable */ 
//# sourceMappingURL=IntraCeoUpdatesWebPart.module.scss.js.map