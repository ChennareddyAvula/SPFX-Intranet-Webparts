import { Version } from '@microsoft/sp-core-library';
import { BaseClientSideWebPart, IPropertyPaneConfiguration } from '@microsoft/sp-webpart-base';
export interface IIntraCeoUpdatesWebPartProps {
    description: string;
}
export interface ISPLists {
    value: ISPList[];
}
export interface ISPList {
    Image: string;
    Description: string;
    Title: string;
}
export default class IntraCeoUpdatesWebPart extends BaseClientSideWebPart<IIntraCeoUpdatesWebPartProps> {
    render(): void;
    protected readonly dataVersion: Version;
    private _getListByCeoUpdates;
    private _renderListAsync;
    private renderCeoUpdates;
    protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration;
}
