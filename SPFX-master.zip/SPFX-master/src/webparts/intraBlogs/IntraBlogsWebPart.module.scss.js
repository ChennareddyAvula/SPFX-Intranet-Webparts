"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
/* tslint:disable */
require("./IntraBlogsWebPart.module.css");
var styles = {
    intraBlogs: 'intraBlogs_882cdec2',
    container: 'container_882cdec2',
    row: 'row_882cdec2',
    column: 'column_882cdec2',
    'ms-Grid': 'ms-Grid_882cdec2',
    title: 'title_882cdec2',
    subTitle: 'subTitle_882cdec2',
    description: 'description_882cdec2',
    button: 'button_882cdec2',
    label: 'label_882cdec2',
};
exports.default = styles;
/* tslint:enable */ 
//# sourceMappingURL=IntraBlogsWebPart.module.scss.js.map