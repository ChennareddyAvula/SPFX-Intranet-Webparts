declare interface IIntraBlogsWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'IntraBlogsWebPartStrings' {
  const strings: IIntraBlogsWebPartStrings;
  export = strings;
}
