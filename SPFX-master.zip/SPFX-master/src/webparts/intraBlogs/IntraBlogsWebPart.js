"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
var sp_core_library_1 = require("@microsoft/sp-core-library");
var sp_webpart_base_1 = require("@microsoft/sp-webpart-base");
var sp_property_pane_1 = require("@microsoft/sp-property-pane");
var webs_1 = require("sp-pnp-js/lib/sharepoint/webs");
var strings = require("IntraBlogsWebPartStrings");
var IntraBlogsWebPart = /** @class */ (function (_super) {
    __extends(IntraBlogsWebPart, _super);
    function IntraBlogsWebPart() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    IntraBlogsWebPart.prototype.render = function () {
        var blogimage = this.context.pageContext.web.absoluteUrl + "/CDN/img/blog.png";
        this.domElement.innerHTML = "\n      <div class=\"col-md-12 rightleftPaddingRemove\">\n      <div class=\"block\">\n        <div class=\"quick_link_header block_header\">\n            <h1><img src=\"" + blogimage + "\" style=\"margin-top:-5px;\"> Blog</h1>\n        </div>\n        <div class=\"height\" id=\"IntraBlog\"></div>        \n      </div>\n    </div>";
        this._renderListAsync();
    };
    Object.defineProperty(IntraBlogsWebPart.prototype, "dataVersion", {
        get: function () {
            return sp_core_library_1.Version.parse('1.0');
        },
        enumerable: true,
        configurable: true
    });
    IntraBlogsWebPart.prototype._getListByIntraBlogs = function () {
        var web = new webs_1.Web(this.context.pageContext.web.absoluteUrl);
        return web.lists.getByTitle('Intra-Blogs').items.orderBy('BlogCreatedDate', false).top(10).get().then(function (items) {
            return items;
        });
    };
    IntraBlogsWebPart.prototype._renderListAsync = function () {
        var _this = this;
        this._getListByIntraBlogs().then(function (EventRes) {
            _this.renderIntraBlogs(EventRes);
        });
    };
    IntraBlogsWebPart.prototype.renderIntraBlogs = function (IntraBloglistitems) {
        var EventAnnhtml = "";
        EventAnnhtml += "";
        IntraBloglistitems.forEach(function (IntraBloglistitems) {
            var deslength = IntraBloglistitems.Description.substring(0, 170);
            var descc = IntraBloglistitems.Description.length;
            if (descc < 170) {
                EventAnnhtml += "\n        <div class=\"row blog_main\">\n\t\t\t\t  <div class=\"col-md-2 float-left\">\n\t\t\t\t\t    <div class=\"date_bg\">" + IntraBloglistitems.BlogCreated + "</div>\n\t\t\t\t  </div>\n          <div class=\"col-md-10 float-left blog_desc\">\n            <h3>" + IntraBloglistitems.Title + "</h3>\n\t\t\t\t\t  <p>" + deslength + "</p>\n            <hr>\n          </div>\n        </div>";
            }
            else if (descc >= 170) {
                EventAnnhtml += "\n          <div class=\"row blog_main\">\n\t\t\t\t  <div class=\"col-md-2 float-left\">\n\t\t\t\t\t    <div class=\"date_bg\">" + IntraBloglistitems.BlogCreated + "</div>\n\t\t\t\t  </div>\n          <div class=\"col-md-10 float-left blog_desc\">\n            <h3>" + IntraBloglistitems.Title + "</h3>\n\t\t\t\t\t  <p>" + deslength + "...<a href =\"" + IntraBloglistitems.Blog_link['Url'] + "\" target= \"_blank\" class=\"read_more\">Read More \u00BB</a></p>\n            <hr>\n          </div>\n        </div>";
            }
            ;
        });
        var EventContainer = this.domElement.querySelector('#IntraBlog');
        if (EventAnnhtml.length > 0) {
            EventContainer.innerHTML = EventAnnhtml;
        }
        else {
            EventContainer.innerHTML = "\n            <div class=\"birthday_main\">\n                <h3>There are no blogs at this time. We will update soon..</h3>\n            </div>\n            <br clear=\"all\">";
        }
    };
    IntraBlogsWebPart.prototype.getPropertyPaneConfiguration = function () {
        return {
            pages: [
                {
                    header: {
                        description: strings.PropertyPaneDescription
                    },
                    groups: [
                        {
                            groupName: strings.BasicGroupName,
                            groupFields: [
                                sp_property_pane_1.PropertyPaneTextField('description', {
                                    label: strings.DescriptionFieldLabel
                                })
                            ]
                        }
                    ]
                }
            ]
        };
    };
    return IntraBlogsWebPart;
}(sp_webpart_base_1.BaseClientSideWebPart));
exports.default = IntraBlogsWebPart;
//# sourceMappingURL=IntraBlogsWebPart.js.map