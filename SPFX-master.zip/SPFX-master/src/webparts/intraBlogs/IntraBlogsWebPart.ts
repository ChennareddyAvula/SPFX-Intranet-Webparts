import { Version } from '@microsoft/sp-core-library';
import { BaseClientSideWebPart } from '@microsoft/sp-webpart-base';
import {
  IPropertyPaneConfiguration,
  PropertyPaneTextField
} from '@microsoft/sp-property-pane';
import { Web } from "sp-pnp-js/lib/sharepoint/webs";
import * as strings from 'IntraBlogsWebPartStrings';

export interface IIntraBlogsWebPartProps {
  description: string;
}
export interface ISPLists {
  value: ISPList[];
}
export interface ISPList {
  Title: string;
  Description: string;
  BlogCreated: any;
  Created: any;
  Blog_link: any;
}

export default class IntraBlogsWebPart extends BaseClientSideWebPart<IIntraBlogsWebPartProps> {

  public render(): void {
    var blogimage = `${this.context.pageContext.web.absoluteUrl}/CDN/img/blog.png`
    this.domElement.innerHTML = `
      <div class="col-md-12 rightleftPaddingRemove">
      <div class="block">
        <div class="quick_link_header block_header">
            <h1><img src="${blogimage}" style="margin-top:-5px;"> Blog</h1>
        </div>
        <div class="height" id="IntraBlog"></div>        
      </div>
    </div>`;
    this._renderListAsync();
  }

  protected get dataVersion(): Version {
    return Version.parse('1.0');
  }
  private _getListByIntraBlogs() {
    let web = new Web(this.context.pageContext.web.absoluteUrl);
      return web.lists.getByTitle('Intra-Blogs').items.orderBy('BlogCreatedDate', false).top(10).get().then((items: any) => {
      return items;
    });
  }
  private _renderListAsync(): any {
    this._getListByIntraBlogs().then((EventRes) => {
      this.renderIntraBlogs(EventRes);
    });
  }
  private renderIntraBlogs(IntraBloglistitems: ISPList[]): void {
    let EventAnnhtml: string = ``;
    EventAnnhtml += ``;
    IntraBloglistitems.forEach((IntraBloglistitems: ISPList) => {
      var deslength = IntraBloglistitems.Description.substring(0, 170);
      var descc = IntraBloglistitems.Description.length;
      if (descc < 170) {
        EventAnnhtml += `
        <div class="row blog_main">
				  <div class="col-md-2 float-left">
					    <div class="date_bg">${IntraBloglistitems.BlogCreated}</div>
				  </div>
          <div class="col-md-10 float-left blog_desc">
            <h3>${IntraBloglistitems.Title}</h3>
					  <p>${deslength}</p>
            <hr>
          </div>
        </div>`
      }
      else if (descc >= 170) {
        EventAnnhtml += `
          <div class="row blog_main">
				  <div class="col-md-2 float-left">
					    <div class="date_bg">${IntraBloglistitems.BlogCreated}</div>
				  </div>
          <div class="col-md-10 float-left blog_desc">
            <h3>${IntraBloglistitems.Title}</h3>
					  <p>${deslength}...<a href ="${IntraBloglistitems.Blog_link['Url']}" target= "_blank" class="read_more">Read More »</a></p>
            <hr>
          </div>
        </div>`};
    });
    const EventContainer: Element = this.domElement.querySelector('#IntraBlog');
    if (EventAnnhtml.length > 0) {
      EventContainer.innerHTML = EventAnnhtml;
    } else {
      EventContainer.innerHTML = `
            <div class="birthday_main">
                <h3>There are no blogs at this time. We will update soon..</h3>
            </div>
            <br clear="all">`
    }
  }

  protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration {
    return {
      pages: [
        {
          header: {
            description: strings.PropertyPaneDescription
          },
          groups: [
            {
              groupName: strings.BasicGroupName,
              groupFields: [
                PropertyPaneTextField('description', {
                  label: strings.DescriptionFieldLabel
                })
              ]
            }
          ]
        }
      ]
    };
  }
}
