import { Version } from '@microsoft/sp-core-library';
import { BaseClientSideWebPart } from '@microsoft/sp-webpart-base';
import { IPropertyPaneConfiguration } from '@microsoft/sp-property-pane';
export interface IIntraBlogsWebPartProps {
    description: string;
}
export interface ISPLists {
    value: ISPList[];
}
export interface ISPList {
    Title: string;
    Description: string;
    BlogCreated: any;
    Created: any;
    Blog_link: any;
}
export default class IntraBlogsWebPart extends BaseClientSideWebPart<IIntraBlogsWebPartProps> {
    render(): void;
    protected readonly dataVersion: Version;
    private _getListByIntraBlogs;
    private _renderListAsync;
    private renderIntraBlogs;
    protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration;
}
