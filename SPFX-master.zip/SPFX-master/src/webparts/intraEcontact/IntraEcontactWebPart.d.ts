import { Version } from '@microsoft/sp-core-library';
import { BaseClientSideWebPart, IPropertyPaneConfiguration } from '@microsoft/sp-webpart-base';
export interface IIntraEcontactWebPartProps {
    description: string;
}
export interface ISPLists {
    value: ISPList[];
}
export interface ISPList {
    Name: string;
    Email: string;
    Designation: string;
    ContactNumber: number;
    EmergencyContactNumber: string;
    ExtenNumber: number;
    OderbyContact: number;
}
export default class IntraEcontactWebPart extends BaseClientSideWebPart<IIntraEcontactWebPartProps> {
    render(): void;
    protected readonly dataVersion: Version;
    private _getListByIntraEcontactList;
    private _renderListAsync;
    private renderIntraEcontactList;
    protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration;
}
