declare interface IIntraEcontactWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'IntraEcontactWebPartStrings' {
  const strings: IIntraEcontactWebPartStrings;
  export = strings;
}
