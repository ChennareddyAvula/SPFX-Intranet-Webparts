"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
var sp_core_library_1 = require("@microsoft/sp-core-library");
var sp_webpart_base_1 = require("@microsoft/sp-webpart-base");
var webs_1 = require("sp-pnp-js/lib/sharepoint/webs");
var strings = require("IntraEcontactWebPartStrings");
var IntraEcontactWebPart = /** @class */ (function (_super) {
    __extends(IntraEcontactWebPart, _super);
    function IntraEcontactWebPart() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    IntraEcontactWebPart.prototype.render = function () {
        this.domElement.innerHTML = "\n    <div class=\"col-md-12 rightleftPaddingRemove\">\n    <div class=\"block\">\n        <div class=\"quick_link_header block_header\">\n            <h1><i class=\"fa fa-phone\" aria-hidden=\"true\"></i> Emergency Contact</h1>\n        </div>\n        <div class=\"height\">\n          <ul class=\"timeline\" id=\"Econtact\">\n          </ul>\n        </div>\n\t</div>\n</div>";
        this._renderListAsync();
    };
    Object.defineProperty(IntraEcontactWebPart.prototype, "dataVersion", {
        get: function () {
            return sp_core_library_1.Version.parse('1.0');
        },
        enumerable: true,
        configurable: true
    });
    IntraEcontactWebPart.prototype._getListByIntraEcontactList = function () {
        var web = new webs_1.Web(this.context.pageContext.web.absoluteUrl);
        return web.lists.getByTitle('Intra-Employees').items.filter('EmergencyContactNumber eq 1').orderBy('OderbyContact', true).top(5000).get().then(function (items) {
            return items;
        });
    };
    IntraEcontactWebPart.prototype._renderListAsync = function () {
        var _this = this;
        this._getListByIntraEcontactList().then(function (EventRes) {
            _this.renderIntraEcontactList(EventRes);
        });
    };
    IntraEcontactWebPart.prototype.renderIntraEcontactList = function (IntraEcontactListitem) {
        var landlineicon = this.context.pageContext.web.absoluteUrl + "/CDN/img/office-phone.png";
        var EventAnnhtml = "";
        EventAnnhtml += "";
        IntraEcontactListitem.forEach(function (IntraEcontactListitem) {
            EventAnnhtml += "        \n                <li>\n                    <span class=\"name\">" + IntraEcontactListitem.Name + "</span>\n                    <span class=\"designation\">" + IntraEcontactListitem.Designation + "</span>\n                    <p class=\"phone\">\n                      <i class=\"fa fa-mobile\" aria-hidden=\"true\"></i> <a>" + IntraEcontactListitem.ContactNumber + "</a>\n                      <i class=\"fa fa-phone\" aria-hidden=\"true\"></i> <a>" + IntraEcontactListitem.ExtenNumber + "</a>\n                    </p>\n                    <p class=\"email\"><span><b><a href=\"mailto:" + IntraEcontactListitem.Email + "\"><i class=\"fa fa-envelope\" aria-hidden=\"true\"></i></a></b></span> <a href=\"mailto:" + IntraEcontactListitem.Email + "\">" + IntraEcontactListitem.Email + "</a></p>\n                </li>";
        });
        var EventContainer = this.domElement.querySelector('#Econtact');
        if (EventAnnhtml.length > 0) {
            EventContainer.innerHTML = EventAnnhtml;
        }
        else {
            EventContainer.innerHTML = "\n          <div class=\"hr\">\n            <div class=\"birthday col-md-12 float-left\">\n              <h3>We are Updating on EmergencyContactDetails.. </h3>\n            </div>\n            <br clear=\"all\">  \n          </div>";
        }
    };
    IntraEcontactWebPart.prototype.getPropertyPaneConfiguration = function () {
        return {
            pages: [
                {
                    header: {
                        description: strings.PropertyPaneDescription
                    },
                    groups: [
                        {
                            groupName: strings.BasicGroupName,
                            groupFields: [
                                sp_webpart_base_1.PropertyPaneTextField('description', {
                                    label: strings.DescriptionFieldLabel
                                })
                            ]
                        }
                    ]
                }
            ]
        };
    };
    return IntraEcontactWebPart;
}(sp_webpart_base_1.BaseClientSideWebPart));
exports.default = IntraEcontactWebPart;
//# sourceMappingURL=IntraEcontactWebPart.js.map