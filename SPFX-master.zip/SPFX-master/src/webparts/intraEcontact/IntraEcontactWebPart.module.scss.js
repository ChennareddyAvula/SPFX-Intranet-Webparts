"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
/* tslint:disable */
require("./IntraEcontactWebPart.module.css");
var styles = {
    intraEcontact: 'intraEcontact_383b6121',
    container: 'container_383b6121',
    row: 'row_383b6121',
    column: 'column_383b6121',
    'ms-Grid': 'ms-Grid_383b6121',
    title: 'title_383b6121',
    subTitle: 'subTitle_383b6121',
    description: 'description_383b6121',
    button: 'button_383b6121',
    label: 'label_383b6121',
};
exports.default = styles;
/* tslint:enable */ 
//# sourceMappingURL=IntraEcontactWebPart.module.scss.js.map