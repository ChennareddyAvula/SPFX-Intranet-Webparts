import { Version } from '@microsoft/sp-core-library';
import {
  BaseClientSideWebPart,
  IPropertyPaneConfiguration,
  PropertyPaneTextField
} from '@microsoft/sp-webpart-base';
import { Web } from "sp-pnp-js/lib/sharepoint/webs";
import * as strings from 'IntraEcontactWebPartStrings';

export interface IIntraEcontactWebPartProps {
  description: string;
}
export interface ISPLists {
  value: ISPList[];
}
export interface ISPList {
  Name: string;
  Email: string;
  Designation: string;
  ContactNumber: number;
  EmergencyContactNumber: string;
  ExtenNumber:number;
  OderbyContact: number;
}

export default class IntraEcontactWebPart extends BaseClientSideWebPart<IIntraEcontactWebPartProps> {
  public render(): void {
    this.domElement.innerHTML = `
    <div class="col-md-12 rightleftPaddingRemove">
    <div class="block">
        <div class="quick_link_header block_header">
            <h1><i class="fa fa-phone" aria-hidden="true"></i> Emergency Contact</h1>
        </div>
        <div class="height">
          <ul class="timeline" id="Econtact">
          </ul>
        </div>
	</div>
</div>`;
    this._renderListAsync();
  }

  protected get dataVersion(): Version {
    return Version.parse('1.0');
  }

  private _getListByIntraEcontactList() {
    let web = new Web(this.context.pageContext.web.absoluteUrl);
    return web.lists.getByTitle('Intra-Employees').items.filter('EmergencyContactNumber eq 1').orderBy('OderbyContact', true).top(5000).get().then((items: any) => {
      return items;
    });
  }
  private _renderListAsync(): any {
    this._getListByIntraEcontactList().then((EventRes) => {
      this.renderIntraEcontactList(EventRes);
    });
  }
  private renderIntraEcontactList(IntraEcontactListitem: ISPList[]): void {
    var landlineicon = `${this.context.pageContext.web.absoluteUrl}/CDN/img/office-phone.png`
    let EventAnnhtml: string = ``;
    EventAnnhtml += ``;
    IntraEcontactListitem.forEach((IntraEcontactListitem: ISPList) => {
      EventAnnhtml += `        
                <li>
                    <span class="name">${IntraEcontactListitem.Name}</span>
                    <span class="designation">${IntraEcontactListitem.Designation}</span>
                    <p class="phone">
                      <i class="fa fa-mobile" aria-hidden="true"></i> <a>${IntraEcontactListitem.ContactNumber}</a>
                      <i class="fa fa-phone" aria-hidden="true"></i> <a>${IntraEcontactListitem.ExtenNumber}</a>
                    </p>
                    <p class="email"><span><b><a href="mailto:${IntraEcontactListitem.Email}"><i class="fa fa-envelope" aria-hidden="true"></i></a></b></span> <a href="mailto:${IntraEcontactListitem.Email}">${IntraEcontactListitem.Email}</a></p>
                </li>`});
    const EventContainer: Element = this.domElement.querySelector('#Econtact');
    if (EventAnnhtml.length > 0) {
      EventContainer.innerHTML = EventAnnhtml;
    }
    else {
      EventContainer.innerHTML = `
          <div class="hr">
            <div class="birthday col-md-12 float-left">
              <h3>We are Updating on EmergencyContactDetails.. </h3>
            </div>
            <br clear="all">  
          </div>`;
    }
  }

  protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration {
    return {
      pages: [
        {
          header: {
            description: strings.PropertyPaneDescription
          },
          groups: [
            {
              groupName: strings.BasicGroupName,
              groupFields: [
                PropertyPaneTextField('description', {
                  label: strings.DescriptionFieldLabel
                })
              ]
            }
          ]
        }
      ]
    };
  }
}
