declare interface IIntraWelcomeOnBoardWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'IntraWelcomeOnBoardWebPartStrings' {
  const strings: IIntraWelcomeOnBoardWebPartStrings;
  export = strings;
}
