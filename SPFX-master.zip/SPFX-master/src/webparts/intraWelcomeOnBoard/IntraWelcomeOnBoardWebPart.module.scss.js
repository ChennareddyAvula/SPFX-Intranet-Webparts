"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
/* tslint:disable */
require("./IntraWelcomeOnBoardWebPart.module.css");
var styles = {
    intraWelcomeOnBoard: 'intraWelcomeOnBoard_f8099560',
    container: 'container_f8099560',
    row: 'row_f8099560',
    column: 'column_f8099560',
    'ms-Grid': 'ms-Grid_f8099560',
    title: 'title_f8099560',
    subTitle: 'subTitle_f8099560',
    description: 'description_f8099560',
    button: 'button_f8099560',
    label: 'label_f8099560',
};
exports.default = styles;
/* tslint:enable */ 
//# sourceMappingURL=IntraWelcomeOnBoardWebPart.module.scss.js.map