"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
var sp_core_library_1 = require("@microsoft/sp-core-library");
var sp_webpart_base_1 = require("@microsoft/sp-webpart-base");
var webs_1 = require("sp-pnp-js/lib/sharepoint/webs");
var strings = require("IntraWelcomeOnBoardWebPartStrings");
var IntraWelcomeOnBoardWebPart = /** @class */ (function (_super) {
    __extends(IntraWelcomeOnBoardWebPart, _super);
    function IntraWelcomeOnBoardWebPart() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    IntraWelcomeOnBoardWebPart.prototype.render = function () {
        this.domElement.innerHTML = "\n      <div class=\"col-md-12 rightleftPaddingRemove\">\n          <div class=\"block\">\n              <div class=\"quick_link_header block_header\">\n                  <h1><i class=\"fa fa-user-plus\" aria-hidden=\"true\"></i> Welcome On Board</h1>\n              </div>\n              <div id=\"Employnew\" class=\"birthday_main\">\n              </div>\n          </div>\n      </div>";
        this._renderListAsync();
    };
    Object.defineProperty(IntraWelcomeOnBoardWebPart.prototype, "dataVersion", {
        get: function () {
            return sp_core_library_1.Version.parse('1.0');
        },
        enumerable: true,
        configurable: true
    });
    IntraWelcomeOnBoardWebPart.prototype._getListByIntraWelcomeOnBoard = function () {
        var today = new Date();
        today.setDate(today.getDate() - 30);
        var dd = today.getDate();
        var mm = today.getMonth() + 1;
        var yyyy = today.getFullYear();
        if (dd < 10) {
            var dateonly = "0" + dd;
        }
        else {
            dateonly = dd + "";
        }
        if (mm < 10) {
            var month = "0" + mm;
        }
        else {
            month = dd + "";
        }
        var Lasttendays = mm + '/' + dd + '/' + yyyy;
        var web = new webs_1.Web(this.context.pageContext.web.absoluteUrl);
        return web.lists.getByTitle('Intra-Employees').items.filter("EmployeeJoin ge '" + Lasttendays + "'").orderBy('EmployeeJoin', false).get().then(function (items) {
            //return web.lists.getByTitle('Intra-Employees').items.orderBy('EmployeeJoin', false).top(6).get().then((items: any) => {
            return items;
        });
    };
    IntraWelcomeOnBoardWebPart.prototype._renderListAsync = function () {
        var _this = this;
        this._getListByIntraWelcomeOnBoard().then(function (EventRes) {
            _this.renderIntraWelcomeOnBoardlist(EventRes);
        });
        this._getListByIntraWelcomeOnBoard().then(function (EventRes) {
            _this.renderIntraWelcomeOnBoardlist(EventRes);
        });
    };
    IntraWelcomeOnBoardWebPart.prototype.renderIntraWelcomeOnBoardlist = function (IntraWelcomeOnBoardlistitem) {
        var EventAnnhtml = "";
        EventAnnhtml += "";
        IntraWelcomeOnBoardlistitem.forEach(function (IntraWelcomeOnBoardlistitem) {
            EventAnnhtml += "\n            <div class=\"hr\">\n              <div class=\"birthday_user col-md-4 float-left\">\n                <img src=\"" + IntraWelcomeOnBoardlistitem.EmployeeImage['Url'] + "\">\n              </div>\n              <div class=\"birthday col-md-8 float-left right-text\">  \n                  <h3>" + IntraWelcomeOnBoardlistitem.Name + "</h3>\n                  <p><b>" + IntraWelcomeOnBoardlistitem.Designation + "</b> in <b>" + IntraWelcomeOnBoardlistitem.Technology + "</b></p>          \n                  <p>" + IntraWelcomeOnBoardlistitem.EmpJoinDateMonth + " " + IntraWelcomeOnBoardlistitem.EmpJoinYear + "</p>\n              </div>\n              <br clear=\"all\">\n          </div>";
        });
        var EventContainer = this.domElement.querySelector('#Employnew');
        if (EventAnnhtml.length > 0)
            EventContainer.innerHTML = EventAnnhtml;
        else {
            EventContainer.innerHTML = "\n        <div class=\"hr\">\n            <div class=\"birthday col-md-12 float-left\">\n              <h3>Recently there is no new Joinee.</h3>\n            </div>\n            <br clear=\"all\">  \n          </div>";
        }
    };
    IntraWelcomeOnBoardWebPart.prototype.getPropertyPaneConfiguration = function () {
        return {
            pages: [
                {
                    header: {
                        description: strings.PropertyPaneDescription
                    },
                    groups: [
                        {
                            groupName: strings.BasicGroupName,
                            groupFields: [
                                sp_webpart_base_1.PropertyPaneTextField('description', {
                                    label: strings.DescriptionFieldLabel
                                })
                            ]
                        }
                    ]
                }
            ]
        };
    };
    return IntraWelcomeOnBoardWebPart;
}(sp_webpart_base_1.BaseClientSideWebPart));
exports.default = IntraWelcomeOnBoardWebPart;
//# sourceMappingURL=IntraWelcomeOnBoardWebPart.js.map