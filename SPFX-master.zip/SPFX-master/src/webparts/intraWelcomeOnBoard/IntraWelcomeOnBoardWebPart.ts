import { Version } from '@microsoft/sp-core-library';
import {
  BaseClientSideWebPart,
  IPropertyPaneConfiguration,
  PropertyPaneTextField
} from '@microsoft/sp-webpart-base';
import { Web } from "sp-pnp-js/lib/sharepoint/webs";
import * as strings from 'IntraWelcomeOnBoardWebPartStrings';

export interface IIntraWelcomeOnBoardWebPartProps {
  description: string;
}
export interface ISPLists {
  value: ISPList[];
}
export interface ISPList {
  EmployeeImage: string;
  Name: string;
  Designation: string;
  EmployeeJoin: any;
  Technology:string;
  EmpJoinDateMonth:string;
  EmpJoinYear:string;
}

export default class IntraWelcomeOnBoardWebPart extends BaseClientSideWebPart<IIntraWelcomeOnBoardWebPartProps> {
  public render(): void {
    this.domElement.innerHTML = `
      <div class="col-md-12 rightleftPaddingRemove">
          <div class="block">
              <div class="quick_link_header block_header">
                  <h1><i class="fa fa-user-plus" aria-hidden="true"></i> Welcome On Board</h1>
              </div>
              <div id="Employnew" class="birthday_main">
              </div>
          </div>
      </div>`;
    this._renderListAsync();
  }

  protected get dataVersion(): Version {
    return Version.parse('1.0');
  }

  private _getListByIntraWelcomeOnBoard() {
    var today = new Date();
    today.setDate(today.getDate() - 30);
    var dd = today.getDate();
    var mm = today.getMonth() + 1;
    var yyyy = today.getFullYear();
    if (dd < 10) {
      var dateonly = "0" + dd;
    }else {
        dateonly = dd + "";
    }    
    if (mm < 10) {
      var month = "0" + mm;
    }
    else {
        month = dd + "";
    }    
    var Lasttendays = mm + '/' + dd + '/' + yyyy;
    let web = new Web(this.context.pageContext.web.absoluteUrl);
    return web.lists.getByTitle('Intra-Employees').items.filter("EmployeeJoin ge '" + Lasttendays + "'").orderBy('EmployeeJoin', false).get().then((items: any) => {
      //return web.lists.getByTitle('Intra-Employees').items.orderBy('EmployeeJoin', false).top(6).get().then((items: any) => {
      return items;
    });
  }

  private _renderListAsync(): any {
    this._getListByIntraWelcomeOnBoard().then((EventRes) => {
      this.renderIntraWelcomeOnBoardlist(EventRes);
    });

    this._getListByIntraWelcomeOnBoard().then((EventRes) => {
      this.renderIntraWelcomeOnBoardlist(EventRes);
    });
  }
  private renderIntraWelcomeOnBoardlist(IntraWelcomeOnBoardlistitem: ISPList[]): void {
    let EventAnnhtml: string = ``;
    EventAnnhtml += ``;
    IntraWelcomeOnBoardlistitem.forEach((IntraWelcomeOnBoardlistitem: ISPList) => {
      EventAnnhtml += `
            <div class="hr">
              <div class="birthday_user col-md-4 float-left">
                <img src="${IntraWelcomeOnBoardlistitem.EmployeeImage['Url']}">
              </div>
              <div class="birthday col-md-8 float-left right-text">  
                  <h3>${IntraWelcomeOnBoardlistitem.Name}</h3>
                  <p><b>${IntraWelcomeOnBoardlistitem.Designation}</b> in <b>${IntraWelcomeOnBoardlistitem.Technology}</b></p>          
                  <p>${IntraWelcomeOnBoardlistitem.EmpJoinDateMonth} ${IntraWelcomeOnBoardlistitem.EmpJoinYear}</p>
              </div>
              <br clear="all">
          </div>`
    });
    const EventContainer: Element = this.domElement.querySelector('#Employnew');
    if (EventAnnhtml.length > 0) 
      EventContainer.innerHTML = EventAnnhtml;
    else {
      EventContainer.innerHTML = `
        <div class="hr">
            <div class="birthday col-md-12 float-left">
              <h3>Recently there is no new Joinee.</h3>
            </div>
            <br clear="all">  
          </div>`;
    }
  }

  protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration {
    return {
      pages: [
        {
          header: {
            description: strings.PropertyPaneDescription
          },
          groups: [
            {
              groupName: strings.BasicGroupName,
              groupFields: [
                PropertyPaneTextField('description', {
                  label: strings.DescriptionFieldLabel
                })
              ]
            }
          ]
        }
      ]
    };
  }
}
