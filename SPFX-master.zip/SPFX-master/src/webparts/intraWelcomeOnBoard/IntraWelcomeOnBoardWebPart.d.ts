import { Version } from '@microsoft/sp-core-library';
import { BaseClientSideWebPart, IPropertyPaneConfiguration } from '@microsoft/sp-webpart-base';
export interface IIntraWelcomeOnBoardWebPartProps {
    description: string;
}
export interface ISPLists {
    value: ISPList[];
}
export interface ISPList {
    EmployeeImage: string;
    Name: string;
    Designation: string;
    EmployeeJoin: any;
    Technology: string;
    EmpJoinDateMonth: string;
    EmpJoinYear: string;
}
export default class IntraWelcomeOnBoardWebPart extends BaseClientSideWebPart<IIntraWelcomeOnBoardWebPartProps> {
    render(): void;
    protected readonly dataVersion: Version;
    private _getListByIntraWelcomeOnBoard;
    private _renderListAsync;
    private renderIntraWelcomeOnBoardlist;
    protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration;
}
