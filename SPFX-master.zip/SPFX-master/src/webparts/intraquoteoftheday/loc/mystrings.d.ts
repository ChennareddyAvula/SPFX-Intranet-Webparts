declare interface IIntraquoteofthedayWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'IntraquoteofthedayWebPartStrings' {
  const strings: IIntraquoteofthedayWebPartStrings;
  export = strings;
}
