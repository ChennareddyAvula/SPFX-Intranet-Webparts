import { Version } from '@microsoft/sp-core-library';
import { BaseClientSideWebPart, IPropertyPaneConfiguration } from '@microsoft/sp-webpart-base';
export interface IIntraquoteofthedayWebPartProps {
    description: string;
}
export interface ISPList {
    value: ISPList[];
}
export interface ISPList {
    DailyQuote: string;
    Modified: any;
    author0: string;
    Author: string;
    Created: any;
    QuoteVisibility: string;
}
export default class IntraquoteofthedayWebPart extends BaseClientSideWebPart<IIntraquoteofthedayWebPartProps> {
    render(): void;
    private _setButtonEventHandlers;
    protected readonly dataVersion: Version;
    private _verifyQuote;
    private renderIntraquote;
    private _verifyQuotedata;
    private _getListByIntraquoteofthedaylist;
    private _getListByIntraquoteofthedayaddlist;
    private _renderListAsync;
    private renderIntraquoteofthedayaddlist;
    private renderIntraquoteofthedaylist;
    protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration;
}
