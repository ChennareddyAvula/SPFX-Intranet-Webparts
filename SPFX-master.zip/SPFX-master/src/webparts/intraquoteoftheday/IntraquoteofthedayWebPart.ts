import { Version } from '@microsoft/sp-core-library';
import {
  BaseClientSideWebPart,
  IPropertyPaneConfiguration,
  PropertyPaneTextField
} from '@microsoft/sp-webpart-base';
import { Web } from "sp-pnp-js/lib/sharepoint/webs";
import * as strings from 'IntraquoteofthedayWebPartStrings';

export interface IIntraquoteofthedayWebPartProps {
  description: string;
}
export interface ISPList {
  value: ISPList[];
}
export interface ISPList {
  DailyQuote: string;
  Modified: any;
  author0: string;
  Author: string;
  Created: any;
  QuoteVisibility:string;
}

export default class IntraquoteofthedayWebPart extends BaseClientSideWebPart<IIntraquoteofthedayWebPartProps> {
  public render(): void {
    var newitemurl = `${this.context.pageContext.web.absoluteUrl}/Lists/IntraQuoteoftheday/NewForm.aspx?Source=${this.context.pageContext.web.absoluteUrl}`
    this.domElement.innerHTML = `
    <div class="col-md-12 rightleftPaddingRemove">
        <div class="block hr_policy_main quoteoftheday">
            <div class="quick_link_header block_header">
              <h1><i class="fa fa-quote-left" aria-hidden="true"></i> Quote of the day
              <a id="anchorTag" target="_blank">
	                <i id="addLink" class="fa fa-plus" aria-hidden="true" style="float:right;color: #FFF;margin: 2px 5px 0 0;display:none;"></i></a>
              </h1> 
            </div>
          <div id="Intraquote" class="hr_policy"></div>        
        </div>
    </div>`;
    this._renderListAsync();
    this._setButtonEventHandlers();
  }
  private _setButtonEventHandlers(): void {
    this.domElement.querySelector('#anchorTag').addEventListener('click', () => {
      this._verifyQuote();
    });
  }
  protected get dataVersion(): Version {
    return Version.parse('1.0');
  }
  private _verifyQuote():void {
    this._verifyQuotedata().then((EventRes) => {
      this.renderIntraquote(EventRes);
    });
  }
  private renderIntraquote(IntraQuoteoftheaddListitem: ISPList[]): void {
   IntraQuoteoftheaddListitem.forEach((IntraQuoteoftheaddListitem: ISPList) => {
      var today = new Date();
      var dd = today.getDate();
      var mm = today.getMonth() + 1;
      var yyyy = today.getFullYear();
      var dateonly;
      if (dd < 10) {
        dateonly = "0" + dd;
      } else {
        dateonly = dd + "";
      }
      var month;
      if (mm < 10) {
        month = "0" + mm;
      }
      else {
        month = mm + "";
      }
      var todaydate = yyyy + '-' + month + '-' + dateonly;
      var CreatedDate = new Date(IntraQuoteoftheaddListitem.Modified);
      var cdd = CreatedDate.getDate();
      var cmm = CreatedDate.getMonth() + 1;
      var cyyyy = CreatedDate.getFullYear();
      var cdateonly;
      if (cdd < 10) {
        cdateonly = "0" + cdd;
      } else {
        cdateonly = cdd + "";
      }
      var cmonth;
      if (cmm < 10) {
        cmonth = "0" + cmm;
      }
      else {
        cmonth = cmm + "";
      }
      var createdDT = cyyyy + '-' + cmonth + '-' + cdateonly;
      if (todaydate != createdDT) {
        location.href=`${this.context.pageContext.web.absoluteUrl}/Lists/IntraQuoteoftheday/NewForm.aspx?Source=${this.context.pageContext.web.absoluteUrl}`;
      }
      else{

      }
    });
  }
  private _verifyQuotedata() {
    let web = new Web(this.context.pageContext.web.absoluteUrl);
    return web.lists.getByTitle('IntraQuoteoftheday').items.top(1).filter('QuoteVisibility eq 1').orderBy("Modified", false).get().then((items: any) => {
      return items;
    });
  }
  private _getListByIntraquoteofthedaylist() {
    let web = new Web(this.context.pageContext.web.absoluteUrl);
    return web.lists.getByTitle('IntraQuoteoftheday').items.top(1).filter('QuoteVisibility eq 1').orderBy("Modified", false).get().then((items: any) => {
      return items;
    });
  }
  private _getListByIntraquoteofthedayaddlist() {
    let web = new Web(this.context.pageContext.web.absoluteUrl);
    return web.lists.getByTitle('IntraQuoteoftheday').items.top(1).filter('QuoteVisibility eq 1').orderBy("Modified", false).get().then((items: any) => {
      return items;
    });
  }

  private _renderListAsync(): any {
    this._getListByIntraquoteofthedaylist().then((EventRes) => {
      this.renderIntraquoteofthedaylist(EventRes);
      this._getListByIntraquoteofthedayaddlist().then((EventRes) => {
        this.renderIntraquoteofthedayaddlist(EventRes);
      });
    });
  }
  private renderIntraquoteofthedayaddlist(IntraQuoteoftheaddListitem: ISPList[]): void {
    IntraQuoteoftheaddListitem.forEach((IntraQuoteoftheaddListitem: ISPList) => {
      var today = new Date();
      var dd = today.getDate();
      var mm = today.getMonth() + 1;
      var yyyy = today.getFullYear();
      var dateonly;
      if (dd < 10) {
        dateonly = "0" + dd;
      } else {
        dateonly = dd + "";
      }
      var month;
      if (mm < 10) {
        month = "0" + mm;
      }
      else {
        month = mm + "";
      }
      var todaydate = yyyy + '-' + month + '-' + dateonly;
      var CreatedDate = new Date(IntraQuoteoftheaddListitem.Modified);
      var cdd = CreatedDate.getDate();
      var cmm = CreatedDate.getMonth() + 1;
      var cyyyy = CreatedDate.getFullYear();
      var cdateonly;
      if (cdd < 10) {
        cdateonly = "0" + cdd;
      } else {
        cdateonly = cdd + "";
      }
      var cmonth;
      if (cmm < 10) {
        cmonth = "0" + cmm;
      }
      else {
        cmonth = cmm + "";
      }
      var createdDT = cyyyy + '-' + cmonth + '-' + cdateonly;
      if (todaydate != createdDT) {
        document.getElementById("addLink").style.display = "block";
      }
      else {
        document.getElementById("addLink").style.display = "none";
      }
    });
  }

  private renderIntraquoteofthedaylist(IntraQuoteoftheListitem: ISPList[]): void {
    let EventAnnhtml: string = ``;
    EventAnnhtml += ``;
    IntraQuoteoftheListitem.forEach((IntraQuoteoftheListitem: ISPList) => {
      EventAnnhtml += `
    <p>${IntraQuoteoftheListitem.DailyQuote}</p>
    <p class="author">~ ${IntraQuoteoftheListitem.author0}</p>
    `;
    });
    const EventContainer: Element = this.domElement.querySelector('#Intraquote');
    EventContainer.innerHTML = EventAnnhtml;
  }

  protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration {
    return {
      pages: [
        {
          header: {
            description: strings.PropertyPaneDescription
          },
          groups: [
            {
              groupName: strings.BasicGroupName,
              groupFields: [
                PropertyPaneTextField('description', {
                  label: strings.DescriptionFieldLabel
                })
              ]
            }
          ]
        }
      ]
    };
  }
}