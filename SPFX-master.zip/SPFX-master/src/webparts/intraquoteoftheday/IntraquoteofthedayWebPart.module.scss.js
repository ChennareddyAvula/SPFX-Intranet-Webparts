"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
/* tslint:disable */
require("./IntraquoteofthedayWebPart.module.css");
var styles = {
    intraquoteoftheday: 'intraquoteoftheday_9ebead5e',
    container: 'container_9ebead5e',
    row: 'row_9ebead5e',
    column: 'column_9ebead5e',
    'ms-Grid': 'ms-Grid_9ebead5e',
    title: 'title_9ebead5e',
    subTitle: 'subTitle_9ebead5e',
    description: 'description_9ebead5e',
    button: 'button_9ebead5e',
    label: 'label_9ebead5e',
};
exports.default = styles;
/* tslint:enable */ 
//# sourceMappingURL=IntraquoteofthedayWebPart.module.scss.js.map