"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
/* tslint:disable */
require("./IntraAnnouncentsWebPart.module.css");
var styles = {
    intraAnnouncents: 'intraAnnouncents_fb0b87e0',
    container: 'container_fb0b87e0',
    row: 'row_fb0b87e0',
    column: 'column_fb0b87e0',
    'ms-Grid': 'ms-Grid_fb0b87e0',
    title: 'title_fb0b87e0',
    subTitle: 'subTitle_fb0b87e0',
    description: 'description_fb0b87e0',
    button: 'button_fb0b87e0',
    label: 'label_fb0b87e0',
};
exports.default = styles;
/* tslint:enable */ 
//# sourceMappingURL=IntraAnnouncentsWebPart.module.scss.js.map