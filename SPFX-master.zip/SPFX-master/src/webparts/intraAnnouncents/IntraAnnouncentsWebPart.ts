import { Version } from '@microsoft/sp-core-library';
import { BaseClientSideWebPart } from '@microsoft/sp-webpart-base';
import {
  IPropertyPaneConfiguration,
  PropertyPaneTextField
} from '@microsoft/sp-property-pane';
import { Web } from "sp-pnp-js/lib/sharepoint/webs";
import * as strings from 'IntraAnnouncentsWebPartStrings';

export interface IIntraAnnouncentsWebPartProps {
  description: string;
}
export interface ISPLists {
  value: ISPList[];
}
export interface ISPList {
  Image: string;
  Description: string;
  Title: string;
  ExpireDate: any;
  Modified: any;
}

export default class IntraAnnouncentsWebPart extends BaseClientSideWebPart<IIntraAnnouncentsWebPartProps> {

  public render(): void {
    this.domElement.innerHTML = `
      <div class="col-md-12 rightleftPaddingRemove">
            <div class="block announcement Announce">
                <div class="quick_link_header block_header">
                  <h1><i class="fa fa-bullhorn" aria-hidden="true"></i> Announcement</h1>
                </div>
                <div id="IntraAnnouncement" class="padding intrapadding">
                </div>              
              </div>
      </div>`;
      this._renderListAsync();
  }

  protected get dataVersion(): Version {
    return Version.parse('1.0');
  }
  private _getListByIntraAnnouncements() {
    var Today = new Date();
    var dd = Today.getDate();
    var mm = Today.getMonth() + 1;
    var yyyy = Today.getFullYear();
    var dateonly = "";
    var month = "";
    if (dd < 10) {
      dateonly = "0" + dd;
    }
    else {
      dateonly = dd + "";
    }
    if (mm < 10) {
      month = "0" + mm;
    }
    else {
      month = mm + "";
    }
    var Todaydate = month + '/' + dateonly + '/' + yyyy;
    let web = new Web(this.context.pageContext.web.absoluteUrl);
    return web.lists.getByTitle('Announcement').items.filter("ExpireDate ge '" + Todaydate + "'").orderBy('Modified', false).get().then((items: any) => {
      return items;
    });
  }

  private _renderListAsync(): any {
    this._getListByIntraAnnouncements().then((EventRes) => {
      this.renderIntraAnnouncements(EventRes);
    });
  }

  private renderIntraAnnouncements(IntraAnnouncementsItems: ISPList[]): void {
    let EventAnnhtml: string = ``;
    EventAnnhtml += ``;
    IntraAnnouncementsItems.forEach((IntraAnnouncementsItems: ISPList) => {
      EventAnnhtml += `
            <div class="row margin-top">
                <div class="col-md-4 float-left"> <img src="${IntraAnnouncementsItems.Image['Url']}" alt="" class="img-fluid"/> </div>
                  <div class="col-md-8 title float-left">
                  <h2>${IntraAnnouncementsItems.Title}</h2>
                  <medium>${IntraAnnouncementsItems.Description}</medium></div>
                </div>                             
             </div>`;
    });
    const EventContainer: Element = this.domElement.querySelector('#IntraAnnouncement');
    if (EventAnnhtml.length > 0) {
      EventContainer.innerHTML = EventAnnhtml;
    } else {
      EventContainer.innerHTML = `
            <div class="birthday_main">
                <h3>There are no Announcements events at this time.</h3>
            </div>
            <br clear="all">`
    }
  }

  protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration {
    return {
      pages: [
        {
          header: {
            description: strings.PropertyPaneDescription
          },
          groups: [
            {
              groupName: strings.BasicGroupName,
              groupFields: [
                PropertyPaneTextField('description', {
                  label: strings.DescriptionFieldLabel
                })
              ]
            }
          ]
        }
      ]
    };
  }
}
