declare interface IIntraAnnouncentsWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'IntraAnnouncentsWebPartStrings' {
  const strings: IIntraAnnouncentsWebPartStrings;
  export = strings;
}
