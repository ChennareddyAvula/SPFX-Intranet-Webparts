import { Version } from '@microsoft/sp-core-library';
import { BaseClientSideWebPart } from '@microsoft/sp-webpart-base';
import { IPropertyPaneConfiguration } from '@microsoft/sp-property-pane';
export interface IIntraAnnouncentsWebPartProps {
    description: string;
}
export interface ISPLists {
    value: ISPList[];
}
export interface ISPList {
    Image: string;
    Description: string;
    Title: string;
    ExpireDate: any;
    Modified: any;
}
export default class IntraAnnouncentsWebPart extends BaseClientSideWebPart<IIntraAnnouncentsWebPartProps> {
    render(): void;
    protected readonly dataVersion: Version;
    private _getListByIntraAnnouncements;
    private _renderListAsync;
    private renderIntraAnnouncements;
    protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration;
}
