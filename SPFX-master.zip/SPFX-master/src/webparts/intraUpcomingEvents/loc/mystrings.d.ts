declare interface IIntraUpcomingEventsWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'IntraUpcomingEventsWebPartStrings' {
  const strings: IIntraUpcomingEventsWebPartStrings;
  export = strings;
}
