"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
/* tslint:disable */
require("./IntraUpcomingEventsWebPart.module.css");
var styles = {
    intraUpcomingEvents: 'intraUpcomingEvents_8ccd4518',
    container: 'container_8ccd4518',
    row: 'row_8ccd4518',
    column: 'column_8ccd4518',
    'ms-Grid': 'ms-Grid_8ccd4518',
    title: 'title_8ccd4518',
    subTitle: 'subTitle_8ccd4518',
    description: 'description_8ccd4518',
    button: 'button_8ccd4518',
    label: 'label_8ccd4518',
};
exports.default = styles;
/* tslint:enable */ 
//# sourceMappingURL=IntraUpcomingEventsWebPart.module.scss.js.map