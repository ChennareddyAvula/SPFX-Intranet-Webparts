import { Version } from '@microsoft/sp-core-library';
import { BaseClientSideWebPart } from '@microsoft/sp-webpart-base';
import { IPropertyPaneConfiguration } from '@microsoft/sp-property-pane';
export interface IIntraUpcomingEventsWebPartProps {
    description: string;
}
export interface ISPLists {
    value: ISPList[];
}
export interface ISPList {
    Title: string;
    Location: string;
    Description: string;
    EventDay: string;
    EventDaymonth: string;
    EventDateSeparate: any;
    Image: any;
}
export default class IntraUpcomingEventsWebPart extends BaseClientSideWebPart<IIntraUpcomingEventsWebPartProps> {
    render(): void;
    protected readonly dataVersion: Version;
    private _getListByIntranews;
    private _renderListAsync;
    private renderIntraIntranewslist;
    protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration;
}
