"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
var sp_core_library_1 = require("@microsoft/sp-core-library");
var sp_webpart_base_1 = require("@microsoft/sp-webpart-base");
var sp_property_pane_1 = require("@microsoft/sp-property-pane");
var webs_1 = require("sp-pnp-js/lib/sharepoint/webs");
var strings = require("IntraUpcomingEventsWebPartStrings");
var IntraUpcomingEventsWebPart = /** @class */ (function (_super) {
    __extends(IntraUpcomingEventsWebPart, _super);
    function IntraUpcomingEventsWebPart() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    IntraUpcomingEventsWebPart.prototype.render = function () {
        this.domElement.innerHTML = "\n      <div class=\"col-md-12 rightleftPaddingRemove\">\n      <div class=\"block\">\n          <div class=\"quick_link_header block_header\">\n            <h1><i class=\"fa fa-calendar\" aria-hidden=\"true\"></i> Upcoming Events</h1>\n          </div>\n          <div id=\"Upevents\" class=\"padding\">\n          </div>\n           <br clear=\"all\">\n      </div>\n    </div>";
        this._renderListAsync();
    };
    Object.defineProperty(IntraUpcomingEventsWebPart.prototype, "dataVersion", {
        get: function () {
            return sp_core_library_1.Version.parse('1.0');
        },
        enumerable: true,
        configurable: true
    });
    IntraUpcomingEventsWebPart.prototype._getListByIntranews = function () {
        var Today = new Date();
        var dd = Today.getDate();
        var mm = Today.getMonth() + 1;
        var yyyy = Today.getFullYear();
        var CurrentDate = "";
        var Currentmonth = "";
        if (dd < 10) {
            CurrentDate = "0" + dd;
        }
        else {
            CurrentDate = dd + "";
        }
        if (mm < 10) {
            Currentmonth = "0" + mm;
        }
        else {
            Currentmonth = mm + "";
        }
        var CurrentDay = mm + '/' + CurrentDate + '/' + yyyy;
        var web = new webs_1.Web(this.context.pageContext.web.absoluteUrl);
        return web.lists.getByTitle('UpcomingEvents').items.filter("EventDay ge '" + CurrentDay + "'").orderBy('EventDay', true).top(3).get().then(function (items) {
            return items;
        });
    };
    IntraUpcomingEventsWebPart.prototype._renderListAsync = function () {
        var _this = this;
        this._getListByIntranews().then(function (EventRes) {
            _this.renderIntraIntranewslist(EventRes);
        });
    };
    IntraUpcomingEventsWebPart.prototype.renderIntraIntranewslist = function (IntraIntranewslistitem) {
        var EventAnnhtml = "";
        EventAnnhtml += "";
        IntraIntranewslistitem.forEach(function (IntraIntranewslistitem) {
            EventAnnhtml += "\n          <div class=\"col-md-4 mb-2 float-left\">\n            <div class=\"new_box\">\n                <div class=\"new_box_top\">" + IntraIntranewslistitem.EventDaymonth + "</div>\n                <br clear=\"all\">\n                <div class=\"new_box_head\">" + IntraIntranewslistitem.Location + "</div>\n                <div class=\"news_desc\">\n                  <h3>" + IntraIntranewslistitem.Title + "</h3>\n                  <p>" + IntraIntranewslistitem.Description + "</p>\n               </div>\n            </div>   \n          </div>";
        });
        var EventContainer = this.domElement.querySelector('#Upevents');
        if (EventAnnhtml.length > 0) {
            EventContainer.innerHTML = EventAnnhtml;
        }
        else {
            EventContainer.innerHTML = "\n        <div class=\"birthday_main\">           \n            <h3>There are no upcoming events at this time.</h3>\n        </div> \n      ";
        }
    };
    IntraUpcomingEventsWebPart.prototype.getPropertyPaneConfiguration = function () {
        return {
            pages: [
                {
                    header: {
                        description: strings.PropertyPaneDescription
                    },
                    groups: [
                        {
                            groupName: strings.BasicGroupName,
                            groupFields: [
                                sp_property_pane_1.PropertyPaneTextField('description', {
                                    label: strings.DescriptionFieldLabel
                                })
                            ]
                        }
                    ]
                }
            ]
        };
    };
    return IntraUpcomingEventsWebPart;
}(sp_webpart_base_1.BaseClientSideWebPart));
exports.default = IntraUpcomingEventsWebPart;
//# sourceMappingURL=IntraUpcomingEventsWebPart.js.map