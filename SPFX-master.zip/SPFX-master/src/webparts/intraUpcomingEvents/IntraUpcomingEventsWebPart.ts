import { Version } from '@microsoft/sp-core-library';
import { BaseClientSideWebPart } from '@microsoft/sp-webpart-base';
import {
  IPropertyPaneConfiguration,
  PropertyPaneTextField
} from '@microsoft/sp-property-pane';
import { Web } from "sp-pnp-js/lib/sharepoint/webs";
import * as strings from 'IntraUpcomingEventsWebPartStrings';

export interface IIntraUpcomingEventsWebPartProps {
  description: string;
}
export interface ISPLists {
  value: ISPList[];
}
export interface ISPList {
  Title: string;
  Location: string;
  Description: string;
  EventDay: string;
  EventDaymonth: string;
  EventDateSeparate: any;
  Image: any;
}

export default class IntraUpcomingEventsWebPart extends BaseClientSideWebPart<IIntraUpcomingEventsWebPartProps> {

  public render(): void {
    this.domElement.innerHTML = `
      <div class="col-md-12 rightleftPaddingRemove">
      <div class="block">
          <div class="quick_link_header block_header">
            <h1><i class="fa fa-calendar" aria-hidden="true"></i> Upcoming Events</h1>
          </div>
          <div id="Upevents" class="padding">
          </div>
           <br clear="all">
      </div>
    </div>`;
    this._renderListAsync();
  }

  protected get dataVersion(): Version {
    return Version.parse('1.0');
  }
  private _getListByIntranews() {
    var Today = new Date();
    var dd = Today.getDate();
    var mm = Today.getMonth() + 1;
    var yyyy = Today.getFullYear();
    var CurrentDate = "";
    var Currentmonth = "";
    if (dd < 10) {
      CurrentDate = "0" + dd;
    }
    else {
      CurrentDate = dd + "";
    }
    if (mm < 10) {
      Currentmonth = "0" + mm;
    }
    else {
      Currentmonth = mm + "";
    }
    var CurrentDay = mm + '/' + CurrentDate + '/' + yyyy;
    let web = new Web(this.context.pageContext.web.absoluteUrl);
    return web.lists.getByTitle('UpcomingEvents').items.filter("EventDay ge '" + CurrentDay + "'").orderBy('EventDay', true).top(3).get().then((items: any[]) => {
      return items;
    });
  }
  private _renderListAsync(): any {
    this._getListByIntranews().then((EventRes) => {
      this.renderIntraIntranewslist(EventRes);
    });
  }

  private renderIntraIntranewslist(IntraIntranewslistitem: ISPList[]): void {
    let EventAnnhtml: string = ``;
    EventAnnhtml += ``;
    IntraIntranewslistitem.forEach((IntraIntranewslistitem: ISPList) => {
        EventAnnhtml += `
          <div class="col-md-4 mb-2 float-left">
            <div class="new_box">
                <div class="new_box_top">${IntraIntranewslistitem.EventDaymonth}</div>
                <br clear="all">
                <div class="new_box_head">${IntraIntranewslistitem.Location}</div>
                <div class="news_desc">
                  <h3>${IntraIntranewslistitem.Title}</h3>
                  <p>${IntraIntranewslistitem.Description}</p>
               </div>
            </div>   
          </div>`;
    });
    const EventContainer: Element = this.domElement.querySelector('#Upevents');
    if (EventAnnhtml.length > 0) {
      EventContainer.innerHTML = EventAnnhtml;
    } else {
      EventContainer.innerHTML = `
        <div class="birthday_main">           
            <h3>There are no upcoming events at this time.</h3>
        </div> 
      `;
    }
  }

  protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration {
    return {
      pages: [
        {
          header: {
            description: strings.PropertyPaneDescription
          },
          groups: [
            {
              groupName: strings.BasicGroupName,
              groupFields: [
                PropertyPaneTextField('description', {
                  label: strings.DescriptionFieldLabel
                })
              ]
            }
          ]
        }
      ]
    };
  }
}
