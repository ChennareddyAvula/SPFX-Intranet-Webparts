import { Version } from '@microsoft/sp-core-library';
import {
  BaseClientSideWebPart,
  IPropertyPaneConfiguration,
  PropertyPaneTextField
} from '@microsoft/sp-webpart-base';
import { Web } from "sp-pnp-js/lib/sharepoint/webs";
import * as strings from 'IntraQuickLinksWebPartStrings';

export interface IIntraQuickLinksWebPartProps {
  description: string;
}
export interface ISPLists {
  value: ISPList[];
}
export interface ISPList {
  ID: number;
  URL: string;
}

export default class IntraQuickLinksWebPart extends BaseClientSideWebPart<IIntraQuickLinksWebPartProps> {
  public render(): void {
    this.domElement.innerHTML = `
     <div class="col-md-12 rightleftPaddingRemove">
            <div class="quick_links block">
              <div class="quick_link_header block_header">
                <h1><i class="fa fa-link" aria-hidden="true"></i> Quick Links</h1>
              </div>
              <ul  id="qlinks" class="quick_menu"></ul>
            </div>`;
    this._renderListAsync();

  }

  protected get dataVersion(): Version {
    return Version.parse('1.0');
  }

  private _getListByQuickLinks() {
    let web = new Web(this.context.pageContext.web.absoluteUrl);
    return web.lists.getByTitle('Intra-QuickLinks').items.get().then((res) => {
      return res;
    });
  }
  private _renderListAsync(): any {
    this._getListByQuickLinks().then((EventRes) => {
      this.renderquicklinks(EventRes);
    });
  }
  private renderquicklinks(QuickLinkItems: ISPList[]): void {
    let EventAnnhtml: string = ``;
    EventAnnhtml += ``;
    QuickLinkItems.forEach((QuickLinkItems: ISPList) => {
      EventAnnhtml += `
      <li><a href="${QuickLinkItems.URL['Url']}" target="_blank"><i class="fa fa-link" aria-hidden="true"></i>${QuickLinkItems.URL["Description"]}</a></li>`
    })
    const EventContainer: Element = this.domElement.querySelector('#qlinks');
    if(EventAnnhtml!= null){
      EventContainer.innerHTML = EventAnnhtml;      
    }else{
      EventContainer.innerHTML = EventAnnhtml;
    }    
  }

  protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration {
    return {
      pages: [
        {
          header: {
            description: strings.PropertyPaneDescription
          },
          groups: [
            {
              groupName: strings.BasicGroupName,
              groupFields: [
                PropertyPaneTextField('description', {
                  label: strings.DescriptionFieldLabel
                })
              ]
            }
          ]
        }
      ]
    };
  }
}

