declare interface IIntraQuickLinksWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'IntraQuickLinksWebPartStrings' {
  const strings: IIntraQuickLinksWebPartStrings;
  export = strings;
}
