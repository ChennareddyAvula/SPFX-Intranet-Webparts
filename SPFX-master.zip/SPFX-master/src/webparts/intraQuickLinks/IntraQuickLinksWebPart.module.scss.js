"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
/* tslint:disable */
require("./IntraQuickLinksWebPart.module.css");
var styles = {
    intraQuickLinks: 'intraQuickLinks_87c3ead6',
    container: 'container_87c3ead6',
    row: 'row_87c3ead6',
    column: 'column_87c3ead6',
    'ms-Grid': 'ms-Grid_87c3ead6',
    title: 'title_87c3ead6',
    subTitle: 'subTitle_87c3ead6',
    description: 'description_87c3ead6',
    button: 'button_87c3ead6',
    label: 'label_87c3ead6',
};
exports.default = styles;
/* tslint:enable */ 
//# sourceMappingURL=IntraQuickLinksWebPart.module.scss.js.map