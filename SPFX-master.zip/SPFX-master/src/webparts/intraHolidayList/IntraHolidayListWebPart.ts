import { Version } from '@microsoft/sp-core-library';
import {
  BaseClientSideWebPart,
  IPropertyPaneConfiguration,
  PropertyPaneTextField
} from '@microsoft/sp-webpart-base';
import { Web } from "sp-pnp-js/lib/sharepoint/webs";
import * as strings from 'IntraHolidayListWebPartStrings';

export interface IIntraHolidayListWebPartProps {
  description: string;
}
export interface ISPLists {
  value: ISPList[];
}
export interface ISPList {
  Holidays: string;
  Day: number;
  weekdayandmonth: string;
  Date:any;
}
export default class IntraHolidayListWebPart extends BaseClientSideWebPart<IIntraHolidayListWebPartProps> {

  public render(): void {
    this.domElement.innerHTML = `
      	   <div class="col-md-12 rightleftPaddingRemove">
          <div class="block">
              <div class="quick_link_header block_header">
                  <h1><i class="fa fa-glass" aria-hidden="true"></i> Upcoming Holiday's 2019</h1>
              </div>
              <div id="HolidayList" class="birthday_main">
              </div>
          </div>
      </div>`;
    this._renderListAsync();
  }

  protected get dataVersion(): Version {
    return Version.parse('1.0');
  }

  private _getListByIntraHolidayList() {
    var Today = new Date();
    var dd = Today.getDate();
    var mm = Today.getMonth() + 1;
    var yyyy = Today.getFullYear();
    var Todaydate = mm + '/' + dd + '/' + yyyy;
    let web = new Web(this.context.pageContext.web.absoluteUrl);
    return web.lists.getByTitle('Intra-HolidayList').items.filter("Date ge '"+ Todaydate +"'").get().then((res) => {
      return res;
    });
  }
  private _renderListAsync(): any {
    this._getListByIntraHolidayList().then((EventRes) => {
      this.renderIntraHolidayList(EventRes);
    });
  }
  private renderIntraHolidayList(IntraHolidayListitem: ISPList[]): void {
    let EventAnnhtml: string = ``;
    EventAnnhtml += ``;
    IntraHolidayListitem.forEach((IntraHolidayListitem: ISPList) => {
      EventAnnhtml += `
      <div class="hr">
          <div class="birthday col-md-12">
                <h3>${IntraHolidayListitem.Holidays}</h3>
                <p>${IntraHolidayListitem.weekdayandmonth}</p>
          </div>
          <br clear="all">
      </div>`
    })
    const EventContainer: Element = this.domElement.querySelector('#HolidayList');
    EventContainer.innerHTML = EventAnnhtml;
  }

  protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration {
    return {
      pages: [
        {
          header: {
            description: strings.PropertyPaneDescription
          },
          groups: [
            {
              groupName: strings.BasicGroupName,
              groupFields: [
                PropertyPaneTextField('description', {
                  label: strings.DescriptionFieldLabel
                })
              ]
            }
          ]
        }
      ]
    };
  }
}
