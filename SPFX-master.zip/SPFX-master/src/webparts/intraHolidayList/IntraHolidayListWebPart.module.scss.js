"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
/* tslint:disable */
require("./IntraHolidayListWebPart.module.css");
var styles = {
    intraHolidayList: 'intraHolidayList_e75f1415',
    container: 'container_e75f1415',
    row: 'row_e75f1415',
    column: 'column_e75f1415',
    'ms-Grid': 'ms-Grid_e75f1415',
    title: 'title_e75f1415',
    subTitle: 'subTitle_e75f1415',
    description: 'description_e75f1415',
    button: 'button_e75f1415',
    label: 'label_e75f1415',
};
exports.default = styles;
/* tslint:enable */ 
//# sourceMappingURL=IntraHolidayListWebPart.module.scss.js.map