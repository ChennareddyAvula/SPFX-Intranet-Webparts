"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
var sp_core_library_1 = require("@microsoft/sp-core-library");
var sp_webpart_base_1 = require("@microsoft/sp-webpart-base");
var webs_1 = require("sp-pnp-js/lib/sharepoint/webs");
var strings = require("IntraHolidayListWebPartStrings");
var IntraHolidayListWebPart = /** @class */ (function (_super) {
    __extends(IntraHolidayListWebPart, _super);
    function IntraHolidayListWebPart() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    IntraHolidayListWebPart.prototype.render = function () {
        this.domElement.innerHTML = "\n      \t   <div class=\"col-md-12 rightleftPaddingRemove\">\n          <div class=\"block\">\n              <div class=\"quick_link_header block_header\">\n                  <h1><i class=\"fa fa-glass\" aria-hidden=\"true\"></i> Upcoming Holiday's 2019</h1>\n              </div>\n              <div id=\"HolidayList\" class=\"birthday_main\">\n              </div>\n          </div>\n      </div>";
        this._renderListAsync();
    };
    Object.defineProperty(IntraHolidayListWebPart.prototype, "dataVersion", {
        get: function () {
            return sp_core_library_1.Version.parse('1.0');
        },
        enumerable: true,
        configurable: true
    });
    IntraHolidayListWebPart.prototype._getListByIntraHolidayList = function () {
        var Today = new Date();
        var dd = Today.getDate();
        var mm = Today.getMonth() + 1;
        var yyyy = Today.getFullYear();
        var Todaydate = mm + '/' + dd + '/' + yyyy;
        var web = new webs_1.Web(this.context.pageContext.web.absoluteUrl);
        return web.lists.getByTitle('Intra-HolidayList').items.filter("Date ge '" + Todaydate + "'").get().then(function (res) {
            return res;
        });
    };
    IntraHolidayListWebPart.prototype._renderListAsync = function () {
        var _this = this;
        this._getListByIntraHolidayList().then(function (EventRes) {
            _this.renderIntraHolidayList(EventRes);
        });
    };
    IntraHolidayListWebPart.prototype.renderIntraHolidayList = function (IntraHolidayListitem) {
        var EventAnnhtml = "";
        EventAnnhtml += "";
        IntraHolidayListitem.forEach(function (IntraHolidayListitem) {
            EventAnnhtml += "\n      <div class=\"hr\">\n          <div class=\"birthday col-md-12\">\n                <h3>" + IntraHolidayListitem.Holidays + "</h3>\n                <p>" + IntraHolidayListitem.weekdayandmonth + "</p>\n          </div>\n          <br clear=\"all\">\n      </div>";
        });
        var EventContainer = this.domElement.querySelector('#HolidayList');
        EventContainer.innerHTML = EventAnnhtml;
    };
    IntraHolidayListWebPart.prototype.getPropertyPaneConfiguration = function () {
        return {
            pages: [
                {
                    header: {
                        description: strings.PropertyPaneDescription
                    },
                    groups: [
                        {
                            groupName: strings.BasicGroupName,
                            groupFields: [
                                sp_webpart_base_1.PropertyPaneTextField('description', {
                                    label: strings.DescriptionFieldLabel
                                })
                            ]
                        }
                    ]
                }
            ]
        };
    };
    return IntraHolidayListWebPart;
}(sp_webpart_base_1.BaseClientSideWebPart));
exports.default = IntraHolidayListWebPart;
//# sourceMappingURL=IntraHolidayListWebPart.js.map