declare interface IIntraHolidayListWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'IntraHolidayListWebPartStrings' {
  const strings: IIntraHolidayListWebPartStrings;
  export = strings;
}
