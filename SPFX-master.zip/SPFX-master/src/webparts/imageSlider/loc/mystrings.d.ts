declare interface IImageSliderWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'ImageSliderWebPartStrings' {
  const strings: IImageSliderWebPartStrings;
  export = strings;
}
