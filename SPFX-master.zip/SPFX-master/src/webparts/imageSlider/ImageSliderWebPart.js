"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
var sp_core_library_1 = require("@microsoft/sp-core-library");
var sp_webpart_base_1 = require("@microsoft/sp-webpart-base");
var sp_property_pane_1 = require("@microsoft/sp-property-pane");
var sp_loader_1 = require("@microsoft/sp-loader");
var sp_http_1 = require("@microsoft/sp-http");
var strings = require("ImageSliderWebPartStrings");
require("jquery");
require("bootstrap");
var ImageSliderWebPart = /** @class */ (function (_super) {
    __extends(ImageSliderWebPart, _super);
    function ImageSliderWebPart(context) {
        var _this = _super.call(this) || this;
        _this._slides = [];
        sp_loader_1.SPComponentLoader.loadCss("https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css");
        return _this;
    }
    ImageSliderWebPart.prototype.render = function () {
        var _this = this;
        this._getSlides()
            .then(function (response) {
            // get slider images
            response.value.forEach(function (slide) {
                _this._getImage(slide.ID)
                    .then(function (data) {
                    // get the image out of the FieldValuesAsHtml
                    var div = document.createElement('div');
                    div.innerHTML = data.SPFxSliderImage;
                    var img = div.firstChild;
                    // need to do string split inorder to make the url relative
                    var imgUrl = img.src.split(_this.context.pageContext.web.serverRelativeUrl)[1];
                    var item = {
                        Title: slide.Title,
                        Url: _this.context.pageContext.web.absoluteUrl + "/_layouts/15/getpreview.ashx?resolution=2&path=" + _this.context.pageContext.web.serverRelativeUrl + imgUrl + "&clientType=modernWebPart"
                    };
                    _this._slides.push(item);
                })
                    .then(function () {
                    _this.domElement.innerHTML = "\n                <div class=\"row\">\n                <div class=\"col-md-12\">\n                  <div id=\"myCarousel\" class=\"carousel slide\" data-ride=\"carousel\">\n                    <!-- Indicators -->\n                    <ol class=\"carousel-indicators\"></ol>\n                    <!-- Wrapper For Slides -->\n                    <div class=\"carousel-inner\" role=\"listbox\"></div>\n                    <!-- Side Controls -->\n                    <a class=\"carousel-control left\" href=\"#myCarousel\" data-slide=\"prev\"><i class=\"fa fa-angle-left\"></i></a>\n                    <a class=\"carousel-control right\" href=\"#myCarousel\" data-slide=\"next\"><i class=\"fa fa-angle-right\"></i></a>\n                  </div>\n                  </div>\n                </div>";
                    // add carousel items to domElement
                    if (_this._slides.length > 0) {
                        _this._slides.forEach(function (item, index) {
                            jQuery('.carousel-indicators', _this.domElement).append(_this._itemCarouselIndicators(index));
                            jQuery('.carousel-inner', _this.domElement).append(_this._itemSlideWrapper(item, index));
                        });
                    }
                    // initialize the slider
                    jQuery('#myCarousel').carousel({
                        interval: 7000
                    });
                });
                //console.log(img.src);           
            });
        });
    };
    Object.defineProperty(ImageSliderWebPart.prototype, "dataVersion", {
        get: function () {
            return sp_core_library_1.Version.parse('1.0');
        },
        enumerable: true,
        configurable: true
    });
    ImageSliderWebPart.prototype._getSlides = function () {
        return this.context.spHttpClient.get(this.context.pageContext.web.absoluteUrl + "/_api/web/lists/getByTitle('SPFx List')/items?$orderBy=SPFxOrder asc", sp_http_1.SPHttpClient.configurations.v1)
            .then(function (response) {
            return response.json();
        });
    };
    ImageSliderWebPart.prototype._getImage = function (id) {
        return this.context.spHttpClient.get(this.context.pageContext.web.absoluteUrl + "/_api/web/lists/getByTitle('SPFx List')/items('" + id + "')/FieldValuesAsHtml", sp_http_1.SPHttpClient.configurations.v1)
            .then(function (response) {
            return response.json();
        });
    };
    ImageSliderWebPart.prototype._itemCarouselIndicators = function (index) {
        if (index == 0) {
            return "<li data-target=\"#myCarousel\" data-slide-to=\"" + index + "\" class=\"active\"></li>";
        }
        else {
            return "<li data-target=\"#myCarousel\" data-slide-to=\"" + index + "\" class=\"\"></li>";
        }
    };
    ImageSliderWebPart.prototype._itemSlideWrapper = function (item, index) {
        if (index == 0) {
            return "\n      <div class=\"item active\">\n        <img src=\"" + item.Url + "\" class=\"img-responsive\">\n        <span>" + item.Title + "</span>\n      </div>";
        }
        else {
            return "\n      <div class=\"item\">\n        <img src=\"" + item.Url + "\" class=\"img-responsive\">\n        <span>" + item.Title + "</span>\n      </div>";
        }
    };
    ImageSliderWebPart.prototype.getPropertyPaneConfiguration = function () {
        return {
            pages: [
                {
                    header: {
                        description: strings.PropertyPaneDescription
                    },
                    groups: [
                        {
                            groupName: strings.BasicGroupName,
                            groupFields: [
                                sp_property_pane_1.PropertyPaneTextField('description', {
                                    label: strings.DescriptionFieldLabel
                                })
                            ]
                        }
                    ]
                }
            ]
        };
    };
    return ImageSliderWebPart;
}(sp_webpart_base_1.BaseClientSideWebPart));
exports.default = ImageSliderWebPart;
//# sourceMappingURL=ImageSliderWebPart.js.map