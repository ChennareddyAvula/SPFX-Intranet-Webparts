import { Version } from '@microsoft/sp-core-library';
import { BaseClientSideWebPart, IWebPartContext } from '@microsoft/sp-webpart-base';
import { IPropertyPaneConfiguration } from '@microsoft/sp-property-pane';
import 'jquery';
import 'bootstrap';
export interface IImageSliderWebPartProps {
    description: string;
}
export interface ISlides {
    value: ISlide[];
}
export interface ISlide {
    ID: number;
    Title: string;
}
export interface ISlideItem {
    SPFxSliderImage: string;
}
export interface IItemGuid {
    value: string;
}
export interface slides {
    Title: string;
    Url: string;
}
export default class ImageSliderWebPart extends BaseClientSideWebPart<IImageSliderWebPartProps> {
    private _slides;
    constructor(context: IWebPartContext);
    render(): void;
    protected readonly dataVersion: Version;
    private _getSlides;
    private _getImage;
    private _itemCarouselIndicators;
    private _itemSlideWrapper;
    protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration;
}
