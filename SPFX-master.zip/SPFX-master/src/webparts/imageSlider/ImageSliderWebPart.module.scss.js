"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
/* tslint:disable */
require("./ImageSliderWebPart.module.css");
var styles = {
    imageSlider: 'imageSlider_553fa790',
    container: 'container_553fa790',
    row: 'row_553fa790',
    column: 'column_553fa790',
    'ms-Grid': 'ms-Grid_553fa790',
    title: 'title_553fa790',
    subTitle: 'subTitle_553fa790',
    description: 'description_553fa790',
    button: 'button_553fa790',
    label: 'label_553fa790',
};
exports.default = styles;
/* tslint:enable */ 
//# sourceMappingURL=ImageSliderWebPart.module.scss.js.map