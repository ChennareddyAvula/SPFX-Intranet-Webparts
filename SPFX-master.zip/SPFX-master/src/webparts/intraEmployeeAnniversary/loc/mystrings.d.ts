declare interface IIntraEmployeeAnniversaryWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'IntraEmployeeAnniversaryWebPartStrings' {
  const strings: IIntraEmployeeAnniversaryWebPartStrings;
  export = strings;
}
