"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
/* tslint:disable */
require("./IntraEmployeeAnniversaryWebPart.module.css");
var styles = {
    intraEmployeeAnniversary: 'intraEmployeeAnniversary_7f7503cc',
    container: 'container_7f7503cc',
    row: 'row_7f7503cc',
    column: 'column_7f7503cc',
    'ms-Grid': 'ms-Grid_7f7503cc',
    title: 'title_7f7503cc',
    subTitle: 'subTitle_7f7503cc',
    description: 'description_7f7503cc',
    button: 'button_7f7503cc',
    label: 'label_7f7503cc',
};
exports.default = styles;
/* tslint:enable */ 
//# sourceMappingURL=IntraEmployeeAnniversaryWebPart.module.scss.js.map