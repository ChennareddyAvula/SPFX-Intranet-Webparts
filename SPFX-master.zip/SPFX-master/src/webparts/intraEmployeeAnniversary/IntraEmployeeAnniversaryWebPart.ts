import { Version } from '@microsoft/sp-core-library';
import {
  BaseClientSideWebPart,
  IPropertyPaneConfiguration,
  PropertyPaneTextField
} from '@microsoft/sp-webpart-base';
import { Web } from "sp-pnp-js/lib/sharepoint/webs";
import * as strings from 'IntraEmployeeAnniversaryWebPartStrings';

export interface IIntraEmployeeAnniversaryWebPartProps {
  description: string;
}
export interface ISPLists {
  value: ISPList[];
}
export interface ISPList {
  EmployeeImage: string;
  Name: string;
  EmpJoinDate: string;
  EmpJoinMonth: any;
  EmpJoinYear: any;
  EmpJoinDateMonth: string;
  StridelyExp: string;
}

export default class IntraEmployeeAnniversaryWebPart extends BaseClientSideWebPart<IIntraEmployeeAnniversaryWebPartProps> {
  public render(): void {
    this.domElement.innerHTML = `
      <div class="col-md-12 rightleftPaddingRemove">
          <div class="block">
              <div class="quick_link_header block_header">
                <h1><i class="fa fa-gift" aria-hidden="true"></i> Work Anniversary</h1>
              </div>
              <div id="empanniversary" class="birthday_main"></div>
              </div>
          </div>
      </div>`;
    this._renderListAsync();
  }

  protected get dataVersion(): Version {
    return Version.parse('1.0');
  }

  public _getListByIntraEmployeeAnniversary() {
    let web = new Web(this.context.pageContext.web.absoluteUrl);
    return web.lists.getByTitle('Intra-Employees').items.orderBy('EmployeeJoin', true).get().then((items: any[]) => {
    //return web.lists.getByTitle('Intra-Employees').items.get().then((items: any[]) => {
      return items;
    });
  }
  private _renderListAsync(): any {
    this._getListByIntraEmployeeAnniversary().then((EventRes) => {
      this.renderIntraEmployeeAnnniversarylist(EventRes);
    })
  }
  private renderIntraEmployeeAnnniversarylist(IntraEmployeeAnnniversarylistitem: ISPList[]): void {
    let EventAnnhtml: string = ``;
    EventAnnhtml += ``;
    IntraEmployeeAnnniversarylistitem.forEach((IntraEmployeeAnnniversarylistitem: ISPList) => {
      var Today = new Date();
      var dd = Today.getDate();
      var mm = Today.getMonth() + 1;
      var yyyy = Today.getFullYear();
      var CurrentDate = "";
      var Currentmonth = "";
      if (dd < 10) {
        CurrentDate = "0" + dd;
      }
      else {
        CurrentDate = dd + "";
      }
      if (mm < 10) {
        Currentmonth = "0" + mm;
      }
      else {
        Currentmonth = mm + "";
      }
      var CurrentDay = Currentmonth + '/' + CurrentDate + '/' + yyyy;
      var Employejoindate = IntraEmployeeAnnniversarylistitem.EmpJoinDate;
      var EmployejoinMonth = IntraEmployeeAnnniversarylistitem.EmpJoinMonth;
      var Employejoinyear = IntraEmployeeAnnniversarylistitem.EmpJoinYear;
      var yearcal = "";
      if (IntraEmployeeAnnniversarylistitem.StridelyExp == "1") {
        yearcal = IntraEmployeeAnnniversarylistitem.StridelyExp + "st";
      }
      else if (IntraEmployeeAnnniversarylistitem.StridelyExp == "2") {
        yearcal = IntraEmployeeAnnniversarylistitem.StridelyExp + "nd";
      }
      else if (IntraEmployeeAnnniversarylistitem.StridelyExp == "3") {
        yearcal = IntraEmployeeAnnniversarylistitem.StridelyExp + "rd";
      }
      else {
        yearcal = IntraEmployeeAnnniversarylistitem.StridelyExp + "th";
      }      
      //var EmployeeyearDiff = yyyy - Employejoinyear;
      if (Employejoindate == CurrentDate && (Currentmonth == EmployejoinMonth) && (Employejoinyear < yyyy)) {
        EventAnnhtml += `
          <div class="hr">
            <div class="birthday_user col-md-4 float-left">
              <img src="${IntraEmployeeAnnniversarylistitem.EmployeeImage['Url']}">
            </div>
            <div class="birthday col-md-8 float-left">
                <h3>${IntraEmployeeAnnniversarylistitem.Name}</h3>
                <p>Congratulations on completing your <strong>${yearcal}</strong> work anniversary.</p>                
            </div>
              <br clear="all">
          </div>`
      }
    });
    IntraEmployeeAnnniversarylistitem.forEach((IntraEmployeeAnnniversarylistitem: ISPList) => {
      var Today = new Date();
      var dd = Today.getDate();
      var mm = Today.getMonth() + 1;
      var yyyy = Today.getFullYear();
      var CurrentDate = "";
      var Currentmonth = "";
      if (dd < 10) {
        CurrentDate = "0" + dd;
      }
      else {
        CurrentDate = dd + "";
      }
      if (mm < 10) {
        Currentmonth = "0" + mm;
      }
      else {
        Currentmonth = mm + "";
      }
      var CurrentDay = Currentmonth + '/' + CurrentDate + '/' + yyyy;
      var Employejoindate = IntraEmployeeAnnniversarylistitem.EmpJoinDate;
      var EmployejoinMonth = IntraEmployeeAnnniversarylistitem.EmpJoinMonth;
      var Employejoinyear = IntraEmployeeAnnniversarylistitem.EmpJoinYear;
      var yearcal = "";
      if (IntraEmployeeAnnniversarylistitem.StridelyExp == "1") {
        yearcal = IntraEmployeeAnnniversarylistitem.StridelyExp + "st";
      }
      else if (IntraEmployeeAnnniversarylistitem.StridelyExp == "2") {
        yearcal = IntraEmployeeAnnniversarylistitem.StridelyExp + "nd";
      }
      else if (IntraEmployeeAnnniversarylistitem.StridelyExp == "3") {
        yearcal = IntraEmployeeAnnniversarylistitem.StridelyExp + "rd";
      }
      else {
        yearcal = IntraEmployeeAnnniversarylistitem.StridelyExp + "th";
      }      
   if ((CurrentDate < Employejoindate) && (Currentmonth == EmployejoinMonth) && (Employejoinyear < yyyy)) {
        EventAnnhtml += `
          <div class="hr">
            <div class="birthday_user col-md-4 float-left">
              <img src="${IntraEmployeeAnnniversarylistitem.EmployeeImage['Url']}">
            </div>
            <div class="birthday col-md-8 float-left">
                <h3>${IntraEmployeeAnnniversarylistitem.Name}</h3>
            </div>
              <br clear="all">
          </div>`
      }
    });
    const EventContainer: Element = this.domElement.querySelector('#empanniversary');
    if (EventAnnhtml.length > 0) {
      EventContainer.innerHTML = EventAnnhtml;
    } else {
      EventContainer.innerHTML = `
          <div class="hr">
            <div class="birthday col-md-12 float-left">
              <h3>No Anniversary's on this month. Hoping next month.. </h3>
            </div>
            <br clear="all">  
          </div>`;
    }
  }

  protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration {
    return {
      pages: [
        {
          header: {
            description: strings.PropertyPaneDescription
          },
          groups: [
            {
              groupName: strings.BasicGroupName,
              groupFields: [
                PropertyPaneTextField('description', {
                  label: strings.DescriptionFieldLabel
                })
              ]
            }
          ]
        }
      ]
    };
  }
}
