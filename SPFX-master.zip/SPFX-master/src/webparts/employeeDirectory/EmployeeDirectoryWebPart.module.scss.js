"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
/* tslint:disable */
require("./EmployeeDirectoryWebPart.module.css");
var styles = {
    employeeDirectory: 'employeeDirectory_a43529ae',
    container: 'container_a43529ae',
    row: 'row_a43529ae',
    column: 'column_a43529ae',
    'ms-Grid': 'ms-Grid_a43529ae',
    title: 'title_a43529ae',
    subTitle: 'subTitle_a43529ae',
    description: 'description_a43529ae',
    button: 'button_a43529ae',
    label: 'label_a43529ae',
};
exports.default = styles;
/* tslint:enable */ 
//# sourceMappingURL=EmployeeDirectoryWebPart.module.scss.js.map