define([], function() {
    return {
        "PropertyPaneDescription": "Description",
        "BasicGroupName": "Data",
        "ListNameFieldLabel": "List name"
    }
});