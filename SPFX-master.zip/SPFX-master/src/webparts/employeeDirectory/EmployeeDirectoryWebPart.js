"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
var sp_core_library_1 = require("@microsoft/sp-core-library");
var sp_webpart_base_1 = require("@microsoft/sp-webpart-base");
var sp_property_pane_1 = require("@microsoft/sp-property-pane");
var sp_lodash_subset_1 = require("@microsoft/sp-lodash-subset");
var EmployeeDirectoryWebPart_module_scss_1 = require("./EmployeeDirectoryWebPart.module.scss");
var strings = require("EmployeeDirectoryWebPartStrings");
var $ = require("jquery");
require("datatables.net");
var EmployeeDirectoryWebPart = /** @class */ (function (_super) {
    __extends(EmployeeDirectoryWebPart, _super);
    function EmployeeDirectoryWebPart() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    EmployeeDirectoryWebPart.prototype.render = function () {
        this.domElement.innerHTML = "\n    <link rel=\"stylesheet\" type=\"text/css\" href=\"https://cdn.datatables.net/1.10.15/css/jquery.dataTables.min.css\" />\n      <table class=\"display " + EmployeeDirectoryWebPart_module_scss_1.default.employeeDirectory + "\" cellspacing=\"0\" width=\"100%\">\n            <thead>\n                <tr>\n                    <th>Emp ID</th>\n                    <th>Name</th>\n                    <th>Email</th>\n                    <th>Designation</th>\n                    <th>ContactNumber</th>\n                    <th>ExtenNumber</th>\n                </tr>\n            </thead>\n      </table>";
        //Get Data
        $('table', this.domElement).DataTable({
            'ajax': {
                'url': this.context.pageContext.web.absoluteUrl + "/_api/web/lists/getbytitle('" + sp_lodash_subset_1.escape(this.properties.listName) + "')/items?$top=1000&$select=Name,Emp_x0020_ID,Email,Designation,ContactNumber,ExtenNumber,EmployeeImage,EmployeeJoin",
                'headers': { 'Accept': 'application/json;odata=nometadata' },
                'dataSrc': function (data) {
                    return data.value.map(function (item) {
                        return [
                            item.Emp_x0020_ID,
                            item.Name,
                            item.Email,
                            item.Designation,
                            item.ContactNumber,
                            item.ExtenNumber
                            //new Date(item.EmployeeJoin)
                        ];
                    });
                }
            },
        });
        $.fn.dataTable.ext.errMode = 'none';
    };
    Object.defineProperty(EmployeeDirectoryWebPart.prototype, "dataVersion", {
        get: function () {
            return sp_core_library_1.Version.parse('1.0');
        },
        enumerable: true,
        configurable: true
    });
    EmployeeDirectoryWebPart.prototype.getPropertyPaneConfiguration = function () {
        return {
            pages: [
                {
                    header: {
                        description: strings.PropertyPaneDescription
                    },
                    groups: [
                        {
                            groupName: strings.BasicGroupName,
                            groupFields: [
                                sp_property_pane_1.PropertyPaneTextField('listName', {
                                    label: strings.ListNameFieldLabel
                                })
                            ]
                        }
                    ]
                }
            ]
        };
    };
    Object.defineProperty(EmployeeDirectoryWebPart.prototype, "disableReactivePropertyChanges", {
        get: function () {
            return true;
        },
        enumerable: true,
        configurable: true
    });
    return EmployeeDirectoryWebPart;
}(sp_webpart_base_1.BaseClientSideWebPart));
exports.default = EmployeeDirectoryWebPart;
//# sourceMappingURL=EmployeeDirectoryWebPart.js.map