import { Version } from '@microsoft/sp-core-library';
import {
  BaseClientSideWebPart
} from '@microsoft/sp-webpart-base';
import {
  IPropertyPaneConfiguration,
  PropertyPaneTextField
} from '@microsoft/sp-property-pane';
import { escape } from '@microsoft/sp-lodash-subset';
import styles from './EmployeeDirectoryWebPart.module.scss';
import * as strings from 'EmployeeDirectoryWebPartStrings';
import * as $ from 'jquery';
import 'datatables.net';
//import 'moment';
//import './moment-plugin';

interface IRequestItem {
  Name: string;
  Emp_x0020_ID: string;
  Email: string;
  Designation:string;  
  ContactNumber:string;
  ExtenNumber:string;
  EmployeeImage:string;
  EmployeeJoin:string;
}


export interface IEmployeeDirectoryWebPartProps {
  listName: string;
}

export default class EmployeeDirectoryWebPart extends BaseClientSideWebPart<IEmployeeDirectoryWebPartProps> {

  public render(): void {
    this.domElement.innerHTML = `
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.15/css/jquery.dataTables.min.css" />
      <table class="display ${styles.employeeDirectory}" cellspacing="0" width="100%">
            <thead>
                <tr>
                    <th>Emp ID</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Designation</th>
                    <th>ContactNumber</th>
                    <th>ExtenNumber</th>
                </tr>
            </thead>
      </table>`;
    //Get Data
    $('table', this.domElement).DataTable({      
      'ajax': {
        'url':  `${this.context.pageContext.web.absoluteUrl}/_api/web/lists/getbytitle('${escape(this.properties.listName)}')/items?$top=1000&$select=Name,Emp_x0020_ID,Email,Designation,ContactNumber,ExtenNumber,EmployeeImage,EmployeeJoin`,
        'headers': { 'Accept': 'application/json;odata=nometadata' },
        'dataSrc': (data: { value: IRequestItem[] }): any[][] => {
          return data.value.map((item: IRequestItem): any[] => {
            return [              
              item.Emp_x0020_ID,
              item.Name,
              item.Email,
              item.Designation,              
              item.ContactNumber,
              item.ExtenNumber
              //new Date(item.EmployeeJoin)
            ];
          });
        }
      },
      //columnDefs: [{
       // targets: 5,
       // render: ($.fn.DataTable as any).render.moment('DD/MMM/YYYY')
      //}]
    });
    $.fn.dataTable.ext.errMode = 'none';
  }  

  protected get dataVersion(): Version {
    return Version.parse('1.0');
  }

  protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration {
    return {
      pages: [
        {
          header: {
            description: strings.PropertyPaneDescription
          },
          groups: [
            {
              groupName: strings.BasicGroupName,
              groupFields: [
                PropertyPaneTextField('listName', {
                  label: strings.ListNameFieldLabel
                })
              ]
            }
          ]
        }
      ]
    };
  }
  protected get disableReactivePropertyChanges(): boolean {
    return true;
  }
}
